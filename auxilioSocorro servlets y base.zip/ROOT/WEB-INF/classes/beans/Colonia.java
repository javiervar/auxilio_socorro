/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

/**
 *
 * @author GDesarrolloSist
 */
public class Colonia {
 private int coloniaId; 
 private String colonia;
 private String cp;
 private int municipioId;

    /**
     * @return the coloniaId
     */
    public int getColoniaId() {
        return coloniaId;
    }

    /**
     * @param coloniaId the coloniaId to set
     */
    public void setColoniaId(int coloniaId) {
        this.coloniaId = coloniaId;
    }

    /**
     * @return the colonia
     */
    public String getColonia() {
        return colonia;
    }

    /**
     * @param colonia the colonia to set
     */
    public void setColonia(String colonia) {
        this.colonia = colonia;
    }

    /**
     * @return the cp
     */
    public String getCp() {
        return cp;
    }

    /**
     * @param cp the cp to set
     */
    public void setCp(String cp) {
        this.cp = cp;
    }

    /**
     * @return the municipioId
     */
    public int getMunicipioId() {
        return municipioId;
    }

    /**
     * @param municipioId the municipioId to set
     */
    public void setMunicipioId(int municipioId) {
        this.municipioId = municipioId;
    }
 
 
}
