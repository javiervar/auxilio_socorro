/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

/**
 *
 * @author GDesarrolloSist
 */
public class EdoMunCol {
    private Estado unEstado;
    private Municipio unMunicipio;
    private Colonia unaColonia;

    public EdoMunCol(Estado unEstado, Municipio unMunicipio, Colonia unaColonia) {
        this.unEstado = unEstado;
        this.unMunicipio = unMunicipio;
        this.unaColonia = unaColonia;
    }

    /**
     * @return the unEstado
     */
    public Estado getUnEstado() {
        return unEstado;
    }

    /**
     * @param unEstado the unEstado to set
     */
    public void setUnEstado(Estado unEstado) {
        this.unEstado = unEstado;
    }

    /**
     * @return the unMunicipio
     */
    public Municipio getUnMunicipio() {
        return unMunicipio;
    }

    /**
     * @param unMunicipio the unMunicipio to set
     */
    public void setUnMunicipio(Municipio unMunicipio) {
        this.unMunicipio = unMunicipio;
    }

    /**
     * @return the unaColonia
     */
    public Colonia getUnaColonia() {
        return unaColonia;
    }

    /**
     * @param unaColonia the unaColonia to set
     */
    public void setUnaColonia(Colonia unaColonia) {
        this.unaColonia = unaColonia;
    }
    
    
}
