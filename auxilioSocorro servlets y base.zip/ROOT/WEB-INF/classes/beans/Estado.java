package beans;

public class Estado {
	private int edo_id;
	private String edo_estado;
	
	public int getEdo_id() {
		return edo_id;
	}
	public void setEdo_id(int edo_id) {
		this.edo_id = edo_id;
	}
	public String getEdo_estado() {
		return edo_estado;
	}
	public void setEdo_estado(String edo_estado) {
		this.edo_estado = edo_estado;
	}
	
}
