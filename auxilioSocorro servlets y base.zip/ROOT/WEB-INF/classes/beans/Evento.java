package beans;

public class Evento {
	private int eve_id;
	private String eve_tipo;
	
	public int getEve_id() {
		return eve_id;
	}
	public void setEve_id(int eve_id) {
		this.eve_id = eve_id;
	}
	public String getEve_tipo() {
		return eve_tipo;
	}
	public void setEve_tipo(String eve_tipo) {
		this.eve_tipo = eve_tipo;
	}
}
