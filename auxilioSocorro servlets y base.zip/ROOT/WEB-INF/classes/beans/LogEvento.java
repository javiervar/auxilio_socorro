package beans;

public class LogEvento {
	private int loe_id, usr_id;
	public int getLoe_id() {
		return loe_id;
	}
	public void setLoe_id(int loe_id) {
		this.loe_id = loe_id;
	}
	public int getUsr_id() {
		return usr_id;
	}
	public void setUsr_id(int usr_id) {
		this.usr_id = usr_id;
	}
	public String getLoe_descripcion() {
		return loe_descripcion;
	}
	public void setLoe_descripcion(String loe_descripcion) {
		this.loe_descripcion = loe_descripcion;
	}
	public String getLoe_fecha_reporte() {
		return loe_fecha_reporte;
	}
	public void setLoe_fecha_reporte(String loe_fecha_reporte) {
		this.loe_fecha_reporte = loe_fecha_reporte;
	}
	public String getLoe_fecha_creacion() {
		return loe_fecha_creacion;
	}
	public void setLoe_fecha_creacion(String loe_fecha_creacion) {
		this.loe_fecha_creacion = loe_fecha_creacion;
	}
	public String getLoe_latitud() {
		return loe_latitud;
	}
	public void setLoe_latitud(String loe_latitud) {
		this.loe_latitud = loe_latitud;
	}
	public String getLoe_longitud() {
		return loe_longitud;
	}
	public void setLoe_longitud(String loe_longitud) {
		this.loe_longitud = loe_longitud;
	}
	private String loe_descripcion, loe_fecha_reporte, loe_fecha_creacion, loe_latitud, loe_longitud;
}
