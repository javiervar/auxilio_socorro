package beans;

public class LogMensaje {
	private int lom_id, men_id;
	private String lom_fecha_creacion;
	public int getLom_id() {
		return lom_id;
	}
	public void setLom_id(int lom_id) {
		this.lom_id = lom_id;
	}
	public int getMen_id() {
		return men_id;
	}
	public void setMen_id(int men_id) {
		this.men_id = men_id;
	}
	public String getLom_fecha_creacion() {
		return lom_fecha_creacion;
	}
	public void setLom_fecha_creacion(String lom_fecha_creacion) {
		this.lom_fecha_creacion = lom_fecha_creacion;
	}
	
}
