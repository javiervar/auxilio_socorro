/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

/**
 *
 * @author GDesarrolloSist
 */
public class Lugar extends Persona{
    private int Lugar;
    private String longitud;
    private String latitud;
    private int tipoLugar;

    public Lugar() {
    }

    public Lugar(int Lugar, String longitud, String latitud) {
        this.Lugar = Lugar;
        this.longitud = longitud;
        this.latitud = latitud;
        this.setPer_tipo_persona(1);
    }

    /**
     * @return the Lugar
     */
    public int getLugar() {
        return Lugar;
    }

    /**
     * @param Lugar the Lugar to set
     */
    public void setLugar(int Lugar) {
        this.Lugar = Lugar;
    }

    /**
     * @return the longitud
     */
    public String getLongitud() {
        return longitud;
    }

    /**
     * @param longitud the longitud to set
     */
    public void setLongitud(String longitud) {
        this.longitud = longitud;
    }

    /**
     * @return the latitud
     */
    public String getLatitud() {
        return latitud;
    }

    /**
     * @param latitud the latitud to set
     */
    public void setLatitud(String latitud) {
        this.latitud = latitud;
    }

    /**
     * @return the tipoLugar
     */
    public int getTipoLugar() {
        return tipoLugar;
    }

    /**
     * @param tipoLugar the tipoLugar to set
     */
    public void setTipoLugar(int tipoLugar) {
        this.tipoLugar = tipoLugar;
    }
    
    
}
