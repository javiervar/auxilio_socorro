package beans;

public class Mensaje {
	private int men_id, men_estatus;
	private String men_mensaje, men_fecha_creacion;
	public int getMen_id() {
		return men_id;
	}
	public void setMen_id(int men_id) {
		this.men_id = men_id;
	}
	public int getMen_estatus() {
		return men_estatus;
	}
	public void setMen_estatus(int men_estatus) {
		this.men_estatus = men_estatus;
	}
	public String getMen_mensaje() {
		return men_mensaje;
	}
	public void setMen_mensaje(String men_mensaje) {
		this.men_mensaje = men_mensaje;
	}
	public String getMen_fecha_creacion() {
		return men_fecha_creacion;
	}
	public void setMen_fecha_creacion(String men_fecha_creacion) {
		this.men_fecha_creacion = men_fecha_creacion;
	}
	
}
