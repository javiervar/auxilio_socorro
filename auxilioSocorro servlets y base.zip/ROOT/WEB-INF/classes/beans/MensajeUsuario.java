package beans;

public class MensajeUsuario {
	private int men_id, usr_id;

	public int getMen_id() {
		return men_id;
	}

	public void setMen_id(int men_id) {
		this.men_id = men_id;
	}

	public int getUsr_id() {
		return usr_id;
	}

	public void setUsr_id(int usr_id) {
		this.usr_id = usr_id;
	}
}
