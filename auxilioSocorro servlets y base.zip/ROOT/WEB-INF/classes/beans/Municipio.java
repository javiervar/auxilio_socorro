package beans;

public class Municipio {
	private int mun_id, edo_id;
	private String mun_municipio;
	
	public int getMun_id() {
		return mun_id;
	}
	public void setMun_id(int mun_id) {
		this.mun_id = mun_id;
	}
	public int getEdo_id() {
		return edo_id;
	}
	public void setEdo_id(int edo_id) {
		this.edo_id = edo_id;
	}
	public String getMun_municipio() {
		return mun_municipio;
	}
	public void setMun_municipio(String mun_municipio) {
		this.mun_municipio = mun_municipio;
	}
	
}
