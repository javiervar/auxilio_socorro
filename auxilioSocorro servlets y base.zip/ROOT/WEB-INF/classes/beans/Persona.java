package beans;

public class Persona {
	private int per_id, per_tipo_persona;
	private String per_nombre, per_appaterno, per_apmaterno, per_razon_social, per_rfc, per_fecha_nacimiento, per_fecha_constitucion, per_calle, per_numext, per_numint, col_cp, col_colonia, per_email, per_telefono;
	public int getPer_id() {
		return per_id;
	}
	public void setPer_id(int per_id) {
		this.per_id = per_id;
	}
	public int getPer_tipo_persona() {
		return per_tipo_persona;
	}
	public void setPer_tipo_persona(int per_tipo_persona) {
		this.per_tipo_persona = per_tipo_persona;
	}
	public String getPer_nombre() {
		return per_nombre;
	}
	public void setPer_nombre(String per_nombre) {
		this.per_nombre = per_nombre;
	}
	public String getPer_appaterno() {
		return per_appaterno;
	}
	public void setPer_appaterno(String per_appaterno) {
		this.per_appaterno = per_appaterno;
	}
	public String getPer_apmaterno() {
		return per_apmaterno;
	}
	public void setPer_apmaterno(String per_apmaterno) {
		this.per_apmaterno = per_apmaterno;
	}
	public String getPer_razon_social() {
		return per_razon_social;
	}
	public void setPer_razon_social(String per_razon_social) {
		this.per_razon_social = per_razon_social;
	}
	public String getPer_rfc() {
		return per_rfc;
	}
	public void setPer_rfc(String per_rfc) {
		this.per_rfc = per_rfc;
	}
	public String getPer_fecha_nacimiento() {
		return per_fecha_nacimiento;
	}
	public void setPer_fecha_nacimiento(String per_fecha_nacimiento) {
		this.per_fecha_nacimiento = per_fecha_nacimiento;
	}
	public String getPer_fecha_constitucion() {
		return per_fecha_constitucion;
	}
	public void setPer_fecha_constitucion(String per_fecha_constitucion) {
		this.per_fecha_constitucion = per_fecha_constitucion;
	}
	public String getPer_calle() {
		return per_calle;
	}
	public void setPer_calle(String per_calle) {
		this.per_calle = per_calle;
	}
	public String getPer_numext() {
		return per_numext;
	}
	public void setPer_numext(String per_numext) {
		this.per_numext = per_numext;
	}
	public String getPer_numint() {
		return per_numint;
	}
	public void setPer_numint(String per_numint) {
		this.per_numint = per_numint;
	}
	public String getCol_cp() {
		return col_cp;
	}
	public void setCol_cp(String col_cp) {
		this.col_cp = col_cp;
	}
	public String getCol_colonia() {
		return col_colonia;
	}
	public void setCol_colonia(String col_colonia) {
		this.col_colonia = col_colonia;
	}
	public String getPer_email() {
		return per_email;
	}
	public void setPer_email(String per_email) {
		this.per_email = per_email;
	}
	public String getPer_telefono() {
		return per_telefono;
	}
	public void setPer_telefono(String per_telefono) {
		this.per_telefono = per_telefono;
	}
	
}
