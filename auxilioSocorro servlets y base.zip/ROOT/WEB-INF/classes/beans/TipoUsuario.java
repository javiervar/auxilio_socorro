package beans;

public class TipoUsuario {
	private int tus_id;
	public int getTus_id() {
		return tus_id;
	}
	public void setTus_id(int tus_id) {
		this.tus_id = tus_id;
	}
	public String getTus_descripcion() {
		return tus_descripcion;
	}
	public void setTus_descripcion(String tus_descripcion) {
		this.tus_descripcion = tus_descripcion;
	}
	private String tus_descripcion;
}
