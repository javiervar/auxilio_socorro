package beans;

public class Usuario {
	private int usr_id, per_id, tus_id, usr_estatus;
	private String usr_login, usr_password;
	public int getUsr_id() {
		return usr_id;
	}
	public void setUsr_id(int usr_id) {
		this.usr_id = usr_id;
	}
	public int getPer_id() {
		return per_id;
	}
	public void setPer_id(int per_id) {
		this.per_id = per_id;
	}
	public int getTus_id() {
		return tus_id;
	}
	public void setTus_id(int tus_id) {
		this.tus_id = tus_id;
	}
	public int getUsr_estatus() {
		return usr_estatus;
	}
	public void setUsr_estatus(int usr_estatus) {
		this.usr_estatus = usr_estatus;
	}
	public String getUsr_login() {
		return usr_login;
	}
	public void setUsr_login(String usr_login) {
		this.usr_login = usr_login;
	}
	public String getUsr_password() {
		return usr_password;
	}
	public void setUsr_password(String usr_password) {
		this.usr_password = usr_password;
	}
}
