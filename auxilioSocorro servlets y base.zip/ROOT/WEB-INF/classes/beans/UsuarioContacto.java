/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

/**
 *
 * @author octodevs
 */
public class UsuarioContacto {
    private int usuarioId;
    private int tipoContacto;
    private int idUsuarioContacto;
    private String telefono;
    private String mensaje;

    public UsuarioContacto(int usuarioId, int tipoContacto, int idUsuarioContacto, String telefono) {
        this.usuarioId = usuarioId;
        this.tipoContacto = tipoContacto;
        this.idUsuarioContacto = idUsuarioContacto;
        this.telefono = telefono;
    }

    public UsuarioContacto() {
    }

    /**
     * @return the usuarioId
     */
    public int getUsuarioId() {
        return usuarioId;
    }

    /**
     * @param usuarioId the usuarioId to set
     */
    public void setUsuarioId(int usuarioId) {
        this.usuarioId = usuarioId;
    }

    /**
     * @return the tipoContacto
     */
    public int getTipoContacto() {
        return tipoContacto;
    }

    /**
     * @param tipoContacto the tipoContacto to set
     */
    public void setTipoContacto(int tipoContacto) {
        this.tipoContacto = tipoContacto;
    }

    /**
     * @return the idUsuarioContacto
     */
    public int getIdUsuarioContacto() {
        return idUsuarioContacto;
    }

    /**
     * @param idUsuarioContacto the idUsuarioContacto to set
     */
    public void setIdUsuarioContacto(int idUsuarioContacto) {
        this.idUsuarioContacto = idUsuarioContacto;
    }

    /**
     * @return the telefono
     */
    public String getTelefono() {
        return telefono;
    }

    /**
     * @param telefono the telefono to set
     */
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    /**
     * @return the mensaje
     */
    public String getMensaje() {
        return mensaje;
    }

    /**
     * @param mensaje the mensaje to set
     */
    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
    
    
}
