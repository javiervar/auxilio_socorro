package beansDAO;

import beans.Colonia;
import beans.Estado;
import beans.Municipio;
import beansTMP.MuestraEdoMunCol;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import clases.Conexion;
import java.util.ArrayList;
import java.util.List;

public class ColoniaDAO {

    Conexion con = new Conexion();
    PreparedStatement stmt;
    Connection conn;
    ResultSet rs;
    String sql = "";

    public MuestraEdoMunCol obtenLugar(String cp) {
        MuestraEdoMunCol unLugar = null;
        con.crearConexion();
        conn = con.getConexion();
        try {
            String sql = "SELECT DISTINCT EDO_ID,EDO_ESTADO, MUN_ID,MUN_MUNICIPIO "
                    + "FROM ESTADO NATURAL JOIN MUNICIPIO NATURAL JOIN COLONIA WHERE COL_CP=?";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, cp);
            System.out.println(stmt.toString());
            rs = stmt.executeQuery();
            if (rs.next()) {
                unLugar = new MuestraEdoMunCol();
                Estado unEstado = new Estado();
                unEstado.setEdo_id(rs.getInt("EDO_ID"));
                unEstado.setEdo_estado(rs.getString("EDO_ESTADO"));
                unLugar.setUnEstado(unEstado);
                Municipio unMunicipio = new Municipio();
                unMunicipio.setEdo_id(rs.getInt("EDO_ID"));
                unMunicipio.setMun_id(rs.getInt("MUN_ID"));
                unMunicipio.setMun_municipio(rs.getString("MUN_MUNICIPIO"));
                unLugar.setUnMunicipio(unMunicipio);
                unLugar.setListaColonias(consultaLista(cp, rs.getInt("MUN_ID")));
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            con.cierraResultSet(rs);
            con.cierraStatement(stmt);
            con.cierraConexion();
        }
        return unLugar;
    }

    public List<Colonia> consultaLista(String cp, int municipioId) {
        List<Colonia> listaColonias = new ArrayList<Colonia>();
        con.crearConexion();
        conn = con.getConexion();
        try {
            String sql = "SELECT COL_ID, COL_COLONIA FROM COLONIA WHERE COL_CP=? AND MUN_ID=?";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, cp);
            stmt.setInt(2, municipioId);
            System.out.println(stmt.toString());
            rs = stmt.executeQuery();
            while (rs.next()) {
                Colonia unaColonia = new Colonia();
                unaColonia.setColonia(rs.getString("COL_COLONIA"));
                unaColonia.setColoniaId(rs.getInt("COL_ID"));
                unaColonia.setCp(cp);
                unaColonia.setMunicipioId(municipioId);
                listaColonias.add(unaColonia);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
        }
        return listaColonias;
    }
}
