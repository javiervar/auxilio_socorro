package beansDAO;

import beans.Catalogo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import clases.Conexion;
import beans.Estado;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class EstadoDAO {

    Conexion con = new Conexion();
    PreparedStatement stmt;
    Connection conn;
    ResultSet rs;
    Statement st;
    String sql = "";

    public Estado consulta(int edo_id) {
        Estado edo = new Estado();
        con.crearConexion();
        conn = con.getConexion();
        try {
            stmt = conn.prepareStatement("SELECT EDO_ID, EDO_ESTADO FROM ESTADO WHERE EDO_ID = ?");
            stmt.setInt(1, edo_id);
            System.out.println(stmt.toString());
            rs = stmt.executeQuery();
            while (rs.next()) {
                edo.setEdo_estado(rs.getString("EDO_ESTADO"));
                edo.setEdo_id(rs.getInt("EDO_ID"));
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            con.cierraResultSet(rs);
            con.cierraStatement(stmt);
            con.cierraConexion();
        }
        return edo;
    }

    public void inserta(Estado edo) {
        con.crearConexion();
        conn = con.getConexion();
        try {
            stmt = conn.prepareStatement("INSERT INTO ESTADO (EDO_ID, EDO_ESTADO) VALUES (?,?)");
            stmt.setInt(1, edo.getEdo_id());
            stmt.setString(2, edo.getEdo_estado());
            System.out.println(stmt.toString());
            stmt.executeUpdate();

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            con.cierraStatement(stmt);
            con.cierraConexion();
        }
    }

    public void actualiza(Estado edo) {
        con.crearConexion();
        conn = con.getConexion();
        try {
            stmt = conn.prepareStatement("UPDATE ESTADO SET EDO_ESTADO='?' WHERE EDO_ID = ?");
            stmt.setString(1, edo.getEdo_estado());
            stmt.setInt(2, edo.getEdo_id());
            System.out.println(stmt.toString());
            stmt.executeUpdate();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            con.cierraStatement(stmt);
            con.cierraConexion();
        }

    }

    public List<Catalogo> consultaLista() {
        List<Catalogo> listaEstados = new ArrayList<Catalogo>();
        con.crearConexion();
        conn = con.getConexion();
        try {
            String sql = "SELECT EDO_ID,EDO_ESTADO FROM ESTADO;";
            st = conn.createStatement();
            rs = st.executeQuery(sql);
            while (rs.next()) {
                Catalogo unCatalogo = new Catalogo();
                unCatalogo.setDescripcion(rs.getString("EDO_ESTADO"));
                unCatalogo.setId(rs.getInt("EDO_ID"));
                listaEstados.add(unCatalogo);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            con.cierraResultSet(rs);
            con.cierraStatement(st);
            con.cierraConexion();
        }
        return listaEstados;
    }
}
