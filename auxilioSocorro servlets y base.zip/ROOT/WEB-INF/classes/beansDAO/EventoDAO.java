package beansDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import clases.Conexion;
import beans.Evento;

public class EventoDAO {
	
	Conexion con = new Conexion();
	PreparedStatement stmt;
	Connection conn;
	ResultSet rs;
	String sql = "";
	
	public Evento consulta(int eve_id){
		con.crearConexion();
		conn = con.getConexion();
		Evento eve = new Evento();
		
		try {
			stmt = conn.prepareStatement("SELECT EVE_ID, EVE_TIPO FROM EVENTO WHERE EVE_ID = ?");
			stmt.setInt(1, eve_id);
			System.out.println(stmt.toString());
			rs = stmt.executeQuery();
			while(rs.next()){
				eve.setEve_id(eve_id);
				eve.setEve_tipo(rs.getString("EVE_TIPO"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			con.cierraResultSet(rs);
			con.cierraStatement(stmt);
			con.cierraConexion();
		}
		return eve;
	}
	
	public void inserta(Evento eve){
		con.crearConexion();
		conn = con.getConexion();
		try {
			stmt = conn.prepareStatement("INSERT INTO EVENTO (EVE_ID, EVE_TIPO) VALUES (?,?)" );
			stmt.setInt(1, eve.getEve_id());
			stmt.setString(2, eve.getEve_tipo());
			System.out.println(stmt.toString());
			stmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			con.cierraStatement(stmt);
			con.cierraConexion();
		}
	}
	
	public void actualiza(Evento eve){
		con.crearConexion();
		conn = con.getConexion();
		try {
			stmt = conn.prepareStatement("UPDATE EVENTO SET EVE_TIPO='?' WHERE EVE_ID = ?");
			stmt.setString(1, eve.getEve_tipo());
			stmt.setInt(2, eve.getEve_id());
			System.out.println(stmt.toString());
			stmt.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
		} finally{
			con.cierraStatement(stmt);
			con.cierraConexion();
		}
	}
}
