package beansDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import clases.Conexion;
import beans.LogEvento;

public class LogEventoDAO {
	
	Conexion con = new Conexion();
	PreparedStatement stmt;
	Connection conn;
	ResultSet rs;
	String sql = "";
	
	public LogEvento consulta(int loe_id){
		LogEvento loe = new LogEvento();
		con.crearConexion();
		conn = con.getConexion();
		
			try {
				stmt = conn.prepareStatement("SELECT LOE_ID, USR_ID, LOE_DESCRIPCION, LOE_FECHA_REPORTE, LOE_FECHA_CREACION, LOE_LATITUD, LOE_LONGITUD FROM LOG_EVENTO WHERE LOE_ID = ?");
				stmt.setInt(1, loe_id);
				System.out.println(stmt.toString());
				rs = stmt.executeQuery();
				while(rs.next()){
					loe.setLoe_descripcion(rs.getString("LOE_DESCRIPCION"));
					loe.setLoe_fecha_creacion(rs.getString("LOE_FECHA_CREACION"));
					loe.setLoe_fecha_reporte(rs.getString("LOE_FECHA_REPORTE"));
					loe.setLoe_id(rs.getInt("LOE_ID"));
					loe.setLoe_latitud(rs.getString("LOE_LATITUD"));
					loe.setLoe_longitud(rs.getString("LOE_LONGITUD"));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				con.cierraResultSet(rs);
				con.cierraStatement(stmt);
				con.cierraConexion();
			}
	
		return loe;
	}
	public void inserta(LogEvento loe){
		con.crearConexion();
		conn = con.getConexion();
		try {
			stmt = conn.prepareStatement("INSERT INTO LOG_EVENTO (LOE_ID, USR_ID, LOE_DESCRIPCION, "
					+ "LOE_FECHA_REPORTE, LOE_FECHA_CREACION, LOE_LATITUD, LOE_LONGITUD) VALUES (?,?,?,?,?,?,?)" );
			stmt.setInt(1, loe.getLoe_id());
			stmt.setInt(2, loe.getUsr_id());
			stmt.setString(3, loe.getLoe_descripcion());
			stmt.setString(4, loe.getLoe_fecha_reporte());
			stmt.setString(5, loe.getLoe_fecha_creacion());
			stmt.setString(6, loe.getLoe_latitud());
			stmt.setString(7, loe.getLoe_longitud());
			System.out.println(stmt.toString());
			stmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			con.cierraStatement(stmt);
			con.cierraConexion();
		}
	}
	public void actualiza(LogEvento loe){
		con.crearConexion();
		conn = con.getConexion();
		try {
			stmt = conn.prepareStatement("UPDATE LOG_EVENTO SET USR_ID=?, LOE_DESCRIPCION='?', LOE_FECHA_REPORTE='?', LOE_FECHA_CREACION='?',"
					+ " LOE_LATITUD='?', LOE_LONGITUD='?' WHERE LOE_ID = ?");
			stmt.setInt(1, loe.getUsr_id());
			stmt.setString(2, loe.getLoe_descripcion());
			stmt.setString(3, loe.getLoe_fecha_reporte());
			stmt.setString(4, loe.getLoe_fecha_creacion());
			stmt.setString(5, loe.getLoe_latitud());
			stmt.setString(6, loe.getLoe_longitud());
			stmt.setInt(7, loe.getLoe_id());
			System.out.println(stmt.toString());
			stmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			con.cierraStatement(stmt);
			con.cierraConexion();
		}
		
	}
}
