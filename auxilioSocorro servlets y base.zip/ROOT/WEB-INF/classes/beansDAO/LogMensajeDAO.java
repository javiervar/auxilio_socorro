package beansDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import clases.Conexion;
import beans.LogMensaje;

public class LogMensajeDAO {
	
	Conexion con = new Conexion();
	PreparedStatement stmt;
	Connection conn;
	ResultSet rs;
	String sql = "";
	
	public LogMensaje consulta(int lom_id){
		LogMensaje lom = new LogMensaje();
		con.crearConexion();
		conn = con.getConexion();
		try {
			stmt = conn.prepareStatement("SELECT LOM_ID, LOM_FECHA_CREACION, MEN_ID FROM LOG_MENSAJE WHERE LOM_ID = ?");
			stmt.setInt(1, lom_id);
			System.out.println(stmt.toString());
			rs = stmt.executeQuery();
			while(rs.next()){
				lom.setLom_fecha_creacion(rs.getString("LOM_FECHA_CREACION"));
				lom.setLom_id(lom_id);
				lom.setMen_id(rs.getInt(rs.getInt("MEN_ID")));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			con.cierraResultSet(rs);
			con.cierraStatement(stmt);
			con.cierraConexion();
		}
		return lom;
	}
	
	public void inserta(LogMensaje lom){
		con.crearConexion();
		conn = con.getConexion();
		try {
			stmt = conn.prepareStatement("INSERT INTO LOG_MENSAJE (LOM_ID, LOM_FECHA_CREACION, MEN_ID) VALUES (?,'?', ?)");
			stmt.setInt(1, lom.getLom_id());
			stmt.setString(2, lom.getLom_fecha_creacion());
			stmt.setInt(3, lom.getMen_id());
			System.out.println(stmt.toString());
			stmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			con.cierraStatement(stmt);
			con.cierraConexion();
		}
	}
	
	public void actualiza(LogMensaje lom){
		con.crearConexion();
		conn = con.getConexion();
		try {
			stmt = conn.prepareStatement("UPDATE LOG_MENSAJE SET LOM_FECHA_CREACION = '?', MEN_ID = ? WHERE LOM_ID = ?");
			stmt.setString(1, lom.getLom_fecha_creacion());
			stmt.setInt(2, lom.getMen_id());
			stmt.setInt(3, lom.getLom_id());
			System.out.println(stmt.toString());
			stmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			con.cierraStatement(stmt);
			con.cierraConexion();
		}
	}
}
