/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beansDAO;

import beans.Lugar;
import clases.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author octodevs
 */
public class LugarDAO {
    
    Conexion con = new Conexion();
    PreparedStatement stmt;
    Connection conn;
    Statement st;
    ResultSet rs;
    
    public List<Lugar> consulta(int tipoLugar) {
        List<Lugar> losLugares = new ArrayList<Lugar>();
        con.crearConexion();
        conn = con.getConexion();
        try {
            String sql = "SELECT LUG_ID, PER_RAZON_SOCIAL, PER_CALLE, PER_NUMEXT, PER_NUMINT, "
                    + "COL_CP, COL_COLONIA, LUG_LONGITUD, LUG_LATITUD FROM LUGAR NATURAL JOIN PERSONA "
                    + "WHERE TIL_ID=?";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, tipoLugar);
            rs = stmt.executeQuery();
            while (rs.next()) {
                Lugar unLugar = new Lugar();
                unLugar.setPer_razon_social(rs.getString("PER_RAZON_SOCIAL"));
                unLugar.setPer_calle(rs.getString("PER_CALLE"));
                unLugar.setPer_numext(rs.getString("PER_NUMEXT"));
                unLugar.setPer_numint(rs.getString("PER_NUMINT"));
                unLugar.setCol_cp(rs.getString("COL_CP"));
                unLugar.setCol_colonia(rs.getString("COL_COLONIA"));
                unLugar.setLatitud(rs.getString("LUG_LONGITUD"));
                unLugar.setLongitud(rs.getString("LUG_LATITUD"));
                losLugares.add(unLugar);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            con.cierraResultSet(rs);
            con.cierraStatement(stmt);
            con.cierraConexion();
        }
        return losLugares;
    }
    
    public List<Lugar> consulta() {
        List<Lugar> losLugares = new ArrayList<Lugar>();
        con.crearConexion();
        conn = con.getConexion();
        try {
            String sql = "SELECT TIL_ID,LUG_ID, PER_RAZON_SOCIAL, PER_CALLE, PER_NUMEXT, PER_NUMINT, "
                    + "COL_CP, COL_COLONIA, LUG_LONGITUD, LUG_LATITUD FROM LUGAR NATURAL JOIN PERSONA "
                    + "ORDER BY TIL_ID";
            st = conn.createStatement();
            rs = st.executeQuery(sql);
            while (rs.next()) {
                Lugar unLugar = new Lugar();
                unLugar.setLugar(rs.getInt("LUG_ID"));
                unLugar.setTipoLugar(rs.getInt("TIL_ID"));
                unLugar.setPer_razon_social(rs.getString("PER_RAZON_SOCIAL"));
                unLugar.setPer_calle(rs.getString("PER_CALLE"));
                unLugar.setPer_numext(rs.getString("PER_NUMEXT"));
                unLugar.setPer_numint(rs.getString("PER_NUMINT"));
                unLugar.setCol_cp(rs.getString("COL_CP"));
                unLugar.setCol_colonia(rs.getString("COL_COLONIA"));
                unLugar.setLatitud(rs.getString("LUG_LONGITUD"));
                unLugar.setLongitud(rs.getString("LUG_LATITUD"));
                losLugares.add(unLugar);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            con.cierraResultSet(rs);
            con.cierraStatement(st);
            con.cierraConexion();
        }
        return losLugares;
    }
}
