package beansDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import clases.Conexion;
import beans.Mensaje;

public class MensajeDAO {

    Conexion con = new Conexion();
    PreparedStatement stmt;
    Connection conn;
    ResultSet rs;
    String sql = "";

    public Mensaje consulta(int men_id) {
        con.crearConexion();
        conn = con.getConexion();
        Mensaje men = new Mensaje();
        try {
            stmt = conn.prepareStatement("SELECT MEN_ID, MEN_MENSAJE, MEN_FECHA_CREACION, MEN_ESTATUS FROM MENSAJE WHERE MEN_ID = ?");
            stmt.setInt(1, men_id);
            System.out.println(stmt.toString());
            rs = stmt.executeQuery();
            while (rs.next()) {
                men.setMen_estatus(rs.getInt("MEN_ESTATUS"));
                men.setMen_fecha_creacion(rs.getString("MEN_FECHA_CREACION"));
                men.setMen_id(men_id);
                men.setMen_mensaje(rs.getString("MEN_MENSAJE"));
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            con.cierraResultSet(rs);
            con.cierraStatement(stmt);
            con.cierraConexion();
        }

        return men;
    }

    public void inserta(Mensaje men) {
        con.crearConexion();
        conn = con.getConexion();
        try {
            stmt = conn.prepareStatement("INSERT INTO MENSAJE (MEN_ID, MEN_MENSAJE, MEN_FECHA_CREACION, MEN_ESTATUS) VALUES (?, ?, ?, ?)");
            stmt.setInt(1, men.getMen_id());
            stmt.setString(2, men.getMen_mensaje());
            stmt.setString(3, men.getMen_fecha_creacion());
            stmt.setInt(4, men.getMen_estatus());
            System.out.println(stmt.toString());
            stmt.executeUpdate();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            con.cierraStatement(stmt);
            con.cierraConexion();
        }
    }

    public void actualiza(Mensaje men) {
        con.crearConexion();
        conn = con.getConexion();
        try {
            stmt = conn.prepareStatement("UPDATE MENSAJE SET MEN_MENSAJE='?', MEN_FECHA_CREACION='?', MEN_ESTATUS=? WHERE MEN_ID = ?");
            stmt.setString(1, men.getMen_mensaje());
            stmt.setString(2, men.getMen_fecha_creacion());
            stmt.setInt(3, men.getMen_estatus());
            stmt.setInt(4, men.getMen_id());
            System.out.println(stmt.toString());
            stmt.executeUpdate();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            con.cierraStatement(stmt);
            con.cierraConexion();
        }

    }

    public String consultaMensaje(int usuarioId, int tipoContacto) {
        String elMensaje = "";
        con.crearConexion();
        conn = con.getConexion();
        try {
            String sql = "SELECT MEN_MENSAJE FROM MENSAJE NATURAL JOIN MENSAJE_USUARIO "
                    + "WHERE USR_ID=? AND TIC_ID=?;";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, usuarioId);
            stmt.setInt(2, tipoContacto);
            System.out.println(stmt.toString());
            rs = stmt.executeQuery();
            while (rs.next()) {
                elMensaje = rs.getString("MEN_MENSAJE");
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            con.cierraResultSet(rs);
            con.cierraStatement(stmt);
            con.cierraConexion();
        }
        return elMensaje;
    }
}
