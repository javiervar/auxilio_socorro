package beansDAO;

public class MensajeUsuarioDAO {
	
}
