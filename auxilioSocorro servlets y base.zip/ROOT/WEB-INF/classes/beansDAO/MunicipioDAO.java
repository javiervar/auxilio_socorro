package beansDAO;

import beans.Catalogo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import clases.Conexion;
import beans.Municipio;
import java.util.ArrayList;
import java.util.List;

public class MunicipioDAO {

    Conexion con = new Conexion();
    PreparedStatement stmt;
    Connection conn;
    ResultSet rs;
    String sql = "";

    public Municipio consulta(int mun_id) {
        Municipio mun = new Municipio();
        con.crearConexion();
        conn = con.getConexion();
        try {
            stmt = conn.prepareStatement("SELECT MUN_MUNICIPIO, EDO_ID FROM MUNICIPIO WHERE MUN_ID = ?");
            stmt.setInt(1, mun_id);
            System.out.println(stmt.toString());
            rs = stmt.executeQuery();
            while (rs.next()) {
                mun.setEdo_id(rs.getInt("EDO_ID"));
                mun.setMun_id(mun_id);
                mun.setMun_municipio(rs.getString("MUN_MUNICIPIO"));
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            con.cierraResultSet(rs);
            con.cierraStatement(stmt);
            con.cierraConexion();
        }

        return mun;
    }

    public List<Catalogo> consultaLista(int estadoId) {
        List<Catalogo> listaMunicipios = new ArrayList<Catalogo>();
        con.crearConexion();
        conn = con.getConexion();
        try {
            stmt = conn.prepareStatement("SELECT MUN_ID,MUN_MUNICIPIO FROM MUNICIPIO WHERE EDO_ID = ?");
            stmt.setInt(1, estadoId);
            System.out.println(stmt.toString());
            rs = stmt.executeQuery();
            while (rs.next()) {
                Catalogo mun = new Catalogo();
                mun.setId(rs.getInt("MUN_ID"));
                mun.setDescripcion(rs.getString("MUN_MUNICIPIO"));
                listaMunicipios.add(mun);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            con.cierraResultSet(rs);
            con.cierraStatement(stmt);
            con.cierraConexion();
        }

        return listaMunicipios;
    }
}
