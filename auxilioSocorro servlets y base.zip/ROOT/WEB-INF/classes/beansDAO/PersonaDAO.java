package beansDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import beans.Persona;
import clases.Conexion;

public class PersonaDAO {
	
	Conexion con = new Conexion();
	PreparedStatement stmt;
	Connection conn;
	ResultSet rs;
	String sql = "";
	
	public Persona consulta(int per_id){
		Persona per = new Persona();
		con.crearConexion();
		conn = con.getConexion();
		try {
			stmt = conn.prepareStatement("SELECT PER_ID, PER_NOMBRE, PER_APPATERNO, PER_APMATERNO, "
					+ "PER_RAZON_SOCIAL, PER_TIPO_PERSONA, PER_RFC, PER_FECHA_NACIMIENTO, "
					+ "PER_FECHA_CONSTITUCION, PER_CALLE, PER_NUMEXT, PER_NUMINT, COL_CP, COL_COLONIA, "
					+ "PER_EMAIL, PER_TELEFONO FROM PERSONA WHERE PER_ID = ?");
			stmt.setInt(1, per_id);
			System.out.println(stmt.toString());
			rs = stmt.executeQuery();
			while(rs.next()){
				per.setPer_id(rs.getInt("PER_ID"));
				per.setPer_nombre(rs.getString("PER_NOMBRE"));
				per.setPer_appaterno(rs.getString("PER_APPATERNO"));
				per.setPer_apmaterno(rs.getString("PER_APMATERNO"));
				per.setPer_razon_social(rs.getString("PER_RAZON_SOCIAL"));
				per.setPer_tipo_persona(rs.getInt("PER_TIPO_PERSONA"));
				per.setPer_rfc(rs.getString("PER_RFC"));
				per.setPer_fecha_nacimiento(rs.getString("PER_FECHA_NACIMIENTO"));
				per.setPer_fecha_constitucion(rs.getString("PER_FECHA_CONSTITUCION"));
				per.setPer_calle(rs.getString("PER_CALLE"));
				per.setPer_numext(rs.getString("PER_NUMEXT"));
				per.setPer_numint(rs.getString("PER_NUMINT"));
				per.setCol_cp(rs.getString("COL_CP"));
				per.setCol_colonia(rs.getString("COL_COLONIA"));
				per.setPer_email(rs.getString("PER_EMAIL"));
				per.setPer_telefono(rs.getString("PER_TELEFONO"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			con.cierraResultSet(rs);
			con.cierraStatement(stmt);
			con.cierraConexion();
		}
		return per;
	}
	
	public void inserta(Persona per){
		con.crearConexion();
		conn = con.getConexion();
		try {
			stmt = conn.prepareStatement("INSERT INTO PERSONA (PER_ID, PER_NOMBRE, PER_APPATERNO, PER_APMATERNO, PER_RAZON_SOCIAL, "
					+ "PER_TIPO_PERSONA, PER_RFC, PER_FECHA_NACIMIENTO, PER_FECHA_CONSTITUCION, PER_CALLE, PER_NUMEXT, "
					+ "PER_NUMINT, COL_CP, COL_COLONIA, PER_EMAIL, PER_TELEFONO) VALUES "
					+ "(?, '?', '?', '?', '?', ?, '?', '?', '?', '?', '?', '?', '?', '?', '?', '?')");
			stmt.setInt(1, per.getPer_id());
			stmt.setString(2, per.getPer_nombre());
			stmt.setString(3, per.getPer_appaterno());
			stmt.setString(4, per.getPer_apmaterno());
			stmt.setString(5, per.getPer_razon_social());
			stmt.setInt(6, per.getPer_tipo_persona());
			stmt.setString(7, per.getPer_rfc());
			stmt.setString(8, per.getPer_fecha_nacimiento());
			stmt.setString(9, per.getPer_fecha_constitucion());
			stmt.setString(10, per.getPer_calle());
			stmt.setString(11, per.getPer_numext());
			stmt.setString(12, per.getPer_numint());
			stmt.setString(13, per.getCol_cp());
			stmt.setString(14, per.getCol_colonia());
			stmt.setString(15, per.getPer_email());
			stmt.setString(16, per.getPer_telefono());
			System.out.println(stmt.toString());
			stmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			con.cierraStatement(stmt);
			con.cierraConexion();
		}
	}
	
	public void actualiza(Persona per){
		con.crearConexion();
		conn = con.getConexion();
		try {
			stmt = conn.prepareStatement("UPDATE PERSONA SET PER_NOMBRE = '?', PER_APPATERNO = '?', PER_APMATERNO = '?', PER_RAZON_SOCIAL = '?',"
					+ " PER_TIPO_PERSONA = ?, PER_RFC = '?', PER_FECHA_NACIMIENTO = '?', PER_FECHA_CONSTITUCION = '?', PER_CALLE = '?', "
					+ "PER_NUMEXT = '?', PER_NUMINT = '?', COL_CP = '?', COL_COLONIA = '?', PER_EMAIL = '?', PER_TELEFONO = '?' WHERE PER_ID = ?");
			stmt.setString(1, per.getPer_nombre());
			stmt.setString(2, per.getPer_appaterno());
			stmt.setString(3, per.getPer_apmaterno());
			stmt.setString(4, per.getPer_razon_social());
			stmt.setInt(5, per.getPer_tipo_persona());
			stmt.setString(6, per.getPer_rfc());
			stmt.setString(7, per.getPer_fecha_nacimiento());
			stmt.setString(8, per.getPer_fecha_constitucion());
			stmt.setString(9, per.getPer_calle());
			stmt.setString(10, per.getPer_numext());
			stmt.setString(11, per.getPer_numint());
			stmt.setString(12, per.getCol_cp());
			stmt.setString(13, per.getCol_colonia());
			stmt.setString(14, per.getPer_email());
			stmt.setString(15, per.getPer_telefono());
			stmt.setInt(16, per.getPer_id());
			System.out.println(stmt.toString());
			stmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			con.cierraStatement(stmt);
			con.cierraConexion();
		}
	}
}



















