package beansDAO;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import clases.Conexion;
import beans.TipoUsuario;

public class TipoUsuarioDAO {
	
	Conexion con = new Conexion();
	PreparedStatement stmt;
	Connection conn;
	ResultSet rs;
	String sql = "";
	
	public TipoUsuario consulta(int tus_id){
		TipoUsuario tu = new TipoUsuario();
		con.crearConexion();
		conn = con.getConexion();
		try {
			stmt = conn.prepareStatement("SELECT TUS_DESCRIPCION FROM TIPO_USUARIO WHERE TUS_ID = ?");
			stmt.setInt(1, tus_id);
			System.out.println(stmt.toString());
			rs = stmt.executeQuery();
			while(rs.next()){
				tu.setTus_descripcion(rs.getString("TUS_DESCRIPCION"));
				tu.setTus_id(tus_id);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			con.cierraResultSet(rs);
			con.cierraStatement(stmt);
			con.cierraConexion();
		}
		return tu;
	}
}
