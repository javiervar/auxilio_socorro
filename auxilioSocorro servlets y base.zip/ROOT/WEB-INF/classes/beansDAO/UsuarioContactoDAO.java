/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beansDAO;

import beans.UsuarioContacto;
import clases.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author GDesarrolloSist
 */
public class UsuarioContactoDAO {

    Conexion con = new Conexion();
    PreparedStatement stmt;
    Statement st;
    Connection conn;
    ResultSet rs;

    public int consultaId() {
        int id = 0;
        con.crearConexion();
        conn = con.getConexion();
        try {
            String sql = "SELECT UCO_ID AS CONSECUTIVO FROM USUARIO_CONTACTO";
            st = conn.createStatement();
            rs = st.executeQuery(sql);
            if (rs.next()) {
                id = rs.getInt("CONSECUTIVO") + 1;
            } else {
                id = 1;
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            con.cierraResultSet(rs);
            con.cierraStatement(st);
        }
        return id;
    }

    public void inserta(UsuarioContacto usuarioContacto) {
        con.crearConexion();
        conn = con.getConexion();
        int id = this.consultaId();
        try {
            String sql = "INSERT INTO USUARIO_CONTACTO (USR_ID, UCO_ID,TIC_ID,UCO_TELEFONO) VALUES (?,?,?,?)";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, usuarioContacto.getUsuarioId());
            stmt.setInt(2, id);
            stmt.setInt(3, usuarioContacto.getTipoContacto());
            stmt.setString(4, usuarioContacto.getTelefono());
            stmt.executeUpdate();

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            con.cierraConexion();
        }
    }

    public List<UsuarioContacto> consultaContactosPorTipo(int usuarioId) {
        List<UsuarioContacto> otraLista = new ArrayList<UsuarioContacto>();
        PreparedStatement stmt2;
        ResultSet rs2 = null;
        try {
            con.crearConexion();
            conn = con.getConexion();
            MensajeDAO unMensaje = new MensajeDAO();
            String sql = "SELECT USR_ID,UCO_ID,TIC_ID,UCO_TELEFONO FROM USUARIO_CONTACTO WHERE USR_ID=?";
            stmt2 = conn.prepareStatement(sql);
            stmt2.setInt(1, usuarioId);
            System.out.println(stmt2.toString());
            rs2 = stmt2.executeQuery();
            while (rs2.next()) {
                UsuarioContacto unContacto = new UsuarioContacto();
                unContacto.setIdUsuarioContacto(rs2.getInt("UCO_ID"));
                unContacto.setTelefono(rs2.getString("UCO_TELEFONO"));
                unContacto.setTipoContacto(rs2.getInt("TIC_ID"));
                unContacto.setUsuarioId(usuarioId);
                unContacto.setMensaje(unMensaje.consultaMensaje(usuarioId, rs2.getInt("TIC_ID")));
                otraLista.add(unContacto);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            con.cierraResultSet(rs2);
        }
        return otraLista;
    }
}
