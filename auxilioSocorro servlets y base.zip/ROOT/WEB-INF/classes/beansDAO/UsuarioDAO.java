package beansDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import clases.Conexion;
import beans.Usuario;

public class UsuarioDAO {
	
	Conexion con = new Conexion();
	PreparedStatement stmt;
	Connection conn;
	ResultSet rs;
	String sql = "";
	
	public Usuario consulta(int usr_id){
		Usuario usr = new Usuario();
		con.crearConexion();
		conn = con.getConexion();
		try {
			stmt = conn.prepareStatement("SELECT USR_LOGIN, USR_PASSWORD, PER_ID, TUS_ID, USR_ESTATUS FROM USUARIO WHERE USR_ID = ?");
			stmt.setInt(1, usr_id);
			System.out.println(stmt.toString());
			rs = stmt.executeQuery();
			while(rs.next()){
				usr.setUsr_login(rs.getString("USR_LOGIN"));
				usr.setUsr_password(rs.getString("USR_PASSWORD"));
				usr.setPer_id(rs.getInt("PER_ID"));
				usr.setTus_id(rs.getInt("TUS_ID"));
				usr.setUsr_estatus(rs.getInt("USR_ESTATUS"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			con.cierraResultSet(rs);
			con.cierraStatement(stmt);
			con.cierraConexion();
		}
		return usr;		
	}
	
	public void inserta(Usuario usr){
		con.crearConexion();
		conn = con.getConexion();
		try {
			stmt = conn.prepareStatement("INSERT INTO USUARIO (USR_ID, USR_LOGIN, USR_PASSWORD, PER_ID, TUS_ID, USR_ESTATUS) VALUES (?,?,?,?,?,?)");
			stmt.setInt(1, usr.getUsr_id());
			stmt.setString(2, usr.getUsr_login());
			stmt.setString(3, usr.getUsr_password());
			stmt.setInt(4, usr.getPer_id());
			stmt.setInt(5, usr.getTus_id());
			stmt.setInt(6, usr.getUsr_estatus());
			System.out.println(stmt.toString());
			stmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			con.cierraStatement(stmt);
			con.cierraConexion();
		}
	}
	
	public void actualiza(Usuario usr){
		con.crearConexion();
		conn = con.getConexion();
		try {
			stmt = conn.prepareStatement("UPDATE USUARIO SET USR_LOGIN = '?', USR_PASSWORD = '?', PER_ID = ?, "
					+ "TUS_ID = ?, USR_ESTATUS = ? WHERE USR_ID = ?");
			stmt.setString(1, usr.getUsr_login());
			stmt.setString(2, usr.getUsr_password());
			stmt.setInt(3, usr.getPer_id());
			stmt.setInt(4, usr.getTus_id());
			stmt.setInt(5, usr.getUsr_estatus());
			stmt.setInt(6, usr.getUsr_id());
			System.out.println(stmt.toString());
			stmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			con.cierraStatement(stmt);
			con.cierraConexion();
		}
		
	}
}
