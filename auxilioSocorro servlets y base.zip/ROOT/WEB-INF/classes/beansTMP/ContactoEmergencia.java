/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beansTMP;

import beans.UsuarioContacto;
import java.util.List;

/**
 *
 * @author GDesarrolloSist
 */
public class ContactoEmergencia {
    private int tipoContacto;
    private String mensaje;
    private List<UsuarioContacto> listaContactos;

    /**
     * @return the tipoContacto
     */
    public int getTipoContacto() {
        return tipoContacto;
    }

    /**
     * @param tipoContacto the tipoContacto to set
     */
    public void setTipoContacto(int tipoContacto) {
        this.tipoContacto = tipoContacto;
    }

    /**
     * @return the listaContactos
     */
    public List<UsuarioContacto> getListaContactos() {
        return listaContactos;
    }

    /**
     * @param listaContactos the listaContactos to set
     */
    public void setListaContactos(List<UsuarioContacto> listaContactos) {
        this.listaContactos = listaContactos;
    }

    /**
     * @return the mensaje
     */
    public String getMensaje() {
        return mensaje;
    }

    /**
     * @param mensaje the mensaje to set
     */
    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
}
