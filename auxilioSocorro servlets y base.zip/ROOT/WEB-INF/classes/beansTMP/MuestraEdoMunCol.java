/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beansTMP;

import beans.Colonia;
import beans.Estado;
import beans.Municipio;
import java.util.List;

/**
 *
 * @author GDesarrolloSist
 */
public class MuestraEdoMunCol {
    private Estado unEstado;
    private Municipio unMunicipio;
    private List<Colonia> listaColonias;

    public MuestraEdoMunCol() {
    }

    public MuestraEdoMunCol(Estado unEstado, Municipio unMunicipio, List<Colonia> listaColonias) {
        this.unEstado = unEstado;
        this.unMunicipio = unMunicipio;
        this.listaColonias = listaColonias;
    }

    /**
     * @return the unEstado
     */
    public Estado getUnEstado() {
        return unEstado;
    }

    /**
     * @param unEstado the unEstado to set
     */
    public void setUnEstado(Estado unEstado) {
        this.unEstado = unEstado;
    }

    /**
     * @return the unMunicipio
     */
    public Municipio getUnMunicipio() {
        return unMunicipio;
    }

    /**
     * @param unMunicipio the unMunicipio to set
     */
    public void setUnMunicipio(Municipio unMunicipio) {
        this.unMunicipio = unMunicipio;
    }

    /**
     * @return the listaColonias
     */
    public List<Colonia> getListaColonias() {
        return listaColonias;
    }

    /**
     * @param listaColonias the listaColonias to set
     */
    public void setListaColonias(List<Colonia> listaColonias) {
        this.listaColonias = listaColonias;
    }
}
