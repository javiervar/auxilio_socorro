/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beansTMP;

import beans.Catalogo;
import beans.Lugar;
import beans.UsuarioContacto;
import java.util.List;

/**
 *
 * @author octodevs
 */
public class Respuesta {
    private int error;
    private String mensaje;
    private List<Catalogo> listaCatalogo;
    private List<Lugar> listaLugares;
    private List<UsuarioContacto> listaContactos;
    private MuestraEdoMunCol unLugar;
    public Respuesta(){
        
    }

    public Respuesta(int error, String mensaje) {
        this.error = error;
        this.mensaje = mensaje;
    }

    public Respuesta(int error, String mensaje, List<Catalogo> listaCatalogo) {
        this.error = error;
        this.mensaje = mensaje;
        this.listaCatalogo = listaCatalogo;
    }

    public Respuesta(int error, String mensaje, MuestraEdoMunCol unLugar) {
        this.error = error;
        this.mensaje = mensaje;
        this.unLugar = unLugar;
    }
    
           

    /**
     * @return the error
     */
    public int getError() {
        return error;
    }

    /**
     * @param error the error to set
     */
    public void setError(int error) {
        this.error = error;
    }

    /**
     * @return the mensaje
     */
    public String getMensaje() {
        return mensaje;
    }

    /**
     * @param mensaje the mensaje to set
     */
    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    /**
     * @return the listaCatalogo
     */
    public List<Catalogo> getListaCatalogo() {
        return listaCatalogo;
    }

    /**
     * @param listaCatalogo the listaCatalogo to set
     */
    public void setListaCatalogo(List<Catalogo> listaCatalogo) {
        this.listaCatalogo = listaCatalogo;
    }

    /**
     * @return the listaLugares
     */
    public List<Lugar> getListaLugares() {
        return listaLugares;
    }

    /**
     * @param listaLugares the listaLugares to set
     */
    public void setListaLugares(List<Lugar> listaLugares) {
        this.listaLugares = listaLugares;
    }

    /**
     * @return the listaContactos
     */
    public List<UsuarioContacto> getListaContactos() {
        return listaContactos;
    }

    /**
     * @param listaContactos the listaContactos to set
     */
    public void setListaContactos(List<UsuarioContacto> listaContactos) {
        this.listaContactos = listaContactos;
    }
    
    
}
