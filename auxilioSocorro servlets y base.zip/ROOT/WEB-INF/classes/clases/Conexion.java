package clases;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class Conexion {

    private String driver = "", user = "", password = "", database = "", urlDB = "";
    private Connection conexion = null;

    public void crearConexion(String driver, String user, String password, String database, String urlDB) {
        try {
            Class.forName(driver).newInstance();

            String url = urlDB + "/" + database;
            conexion = DriverManager.getConnection(url, user, password);

        } catch (Exception ex) {
            System.out.println(this.getClass().getName() + " --------> Error :" + ex.toString());
        }

        setConexion(conexion);
    }
    
    public void crearConexion(String driver, String user, String password, String database) {
        try {
            Class.forName(driver).newInstance();

            String url = database;
            conexion = DriverManager.getConnection(url, user, password);

        } catch (Exception ex) {
            System.out.println(this.getClass().getName() + " --------> Error :" + ex.toString());
        }

        setConexion(conexion);
    }

    public void crearConexion() {
        obtenerConfiguracionDB();
        try {
            Class.forName(this.driver).newInstance();

            String url = this.urlDB + "/" + this.database;
            conexion = DriverManager.getConnection(url, user, password);

        } catch (Exception ex) {
            System.out.println(this.getClass().getName() + " --------> Error :" + ex.toString());
        }

        setConexion(conexion);
    }

    public java.sql.Connection getConexion() {
        return this.conexion;
    }

    public void setConexion(java.sql.Connection conexion) {
        this.conexion = conexion;
    }

    public void cierraConexion() {
        //this Conexion
        if (this.conexion != null) {
            try {
                this.conexion.close();

            } catch (SQLException e) {

            }
        }
    }

    public void obtenerConfiguracionDB() {
        try {

            Properties props = new Properties();

            FileInputStream file = new FileInputStream("/var/www/vhosts/auxilioSocorro.com/ROOT//configuraciones/configDB.properties");

            props.load(file);
            this.driver = props.getProperty("driver");
            this.user = props.getProperty("user");
            this.password = props.getProperty("password");
            this.database = props.getProperty("database");
            this.urlDB = props.getProperty("url");
            file.close();

        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
        }

    }

    public void cierraStatement(Statement st) {
        if (st != null) {
            try {
                st.close();
            } catch (SQLException e) {

            }

        }
    }

    public void cierraResultSet(ResultSet rs) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {

            }
        }
    }
}
