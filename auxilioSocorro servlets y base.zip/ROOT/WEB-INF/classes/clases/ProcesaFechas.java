
package clases;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 *
 * @author OctoDevs
 */
public class ProcesaFechas {

    /**
     * OBTIENE EL NUMERO DE DIAS QUE HAY ENTRE LA FECHA INICIAL Y LA FECHA FINAL INDICADAS
     *
     * @param D_FechaInicial ES LA FECHA EN LA QUE INICIA EL PERIODO
     * @param D_FechaFinal ES LA FECHA EN LA QUE FINALIZA EL PERIODO
     * @return numero_dias_periodo UN INT CON EL NUMERO DE DIAS QUE HAY ENTRE LA FECHA INICIAL Y LA FINAL, REGRESA -1 SI LA FECHA FINAL ES MENOR QUE LA INICIAL
     */
    public static int obtenDiasEntrePeriodo(Date D_FechaInicial, Date D_FechaFinal) {
        int numero_dias_periodo = -1;

        if (D_FechaFinal.before(D_FechaInicial)) {
            return numero_dias_periodo;
        }

        long diferencia = D_FechaFinal.getTime() - D_FechaInicial.getTime();

        numero_dias_periodo = (int) ((((diferencia / 1000) / 60) / 60) / 24);

        return numero_dias_periodo;
    }

    /**
     * CREA UN OBJETO DATE A PARTIR DE UN STRING CON EL SIGUIENTE FORMATO ("dd/MM/yyy")
     *
     * @param s_Fecha LA FECHA QUE QUEREMOS CREAR
     * @param s_FormatoFecha EL FORMATO QUE LLEVARA LA FECHA QUE QUEREMOS PARSEAR, P.EJ. dd/MM/yyyy
     * @return UN OBJETO DATE CON LA FECHA CREADA
     */
    public static Date crearFecha(String s_Fecha, String s_FormatoFecha) {
        SimpleDateFormat formatoDelTexto = new SimpleDateFormat(s_FormatoFecha);
        Date fecha = null;

        try {
            fecha = formatoDelTexto.parse(s_Fecha);
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        return fecha;
    }

    /**
     * OBTIENE LA HORA DE LA FECHA ESPECIFICADA
     *
     * @param D_Fecha LA FECHA DE LA QUE SE OBTENDRA LA HORA
     * @return UN STRING CON EL SIGUIENTE FORMATO HH:MM
     */
    public static String obtenerHoraReloj(Date D_Fecha) {
        String horaReloj = "";

        if (D_Fecha == null) {
            horaReloj = "00:00";
        } else {
            int i_hora = obtenerHoraDia(D_Fecha);
            int i_minuto = obtenerMinutoDia(D_Fecha);

            String s_hora = "";
            String s_minuto = "";

            if (i_hora < 10) {
                s_hora = "0" + i_hora;
            } else {
                s_hora = "" + i_hora;
            }

            if (i_minuto < 10) {
                s_minuto = "0" + i_minuto;
            } else {
                s_minuto = "" + i_minuto;
            }

            horaReloj = s_hora + ":" + s_minuto;
        }

        return horaReloj;
    }

    /**
     * OBTIENE LA HORA DE LA FECHA INDICADA
     *
     * @param D_Fecha LA FECHA DE LA QUE SE OBTENDRA LA HORA
     * @return UN INT CON LA HORA OBTENIDA
     */
    public static int obtenerHoraDia(Date D_Fecha) {
        int horaDia;

        Calendar calendario = Calendar.getInstance();

        calendario.setTime(D_Fecha);

        horaDia = calendario.get(Calendar.HOUR_OF_DAY);

        return horaDia;
    }

    /**
     * OBTIENE LOS MINUTOS DE LA FECHA INDICADA
     *
     * @param D_Fecha LA FECHA DE LA QUE SE OBTENDRA LOS MINUTOS
     * @return UN INT LOS MINUTOS OBTENIDOS
     */
    public static int obtenerMinutoDia(Date D_Fecha) {
        int minutoDia;

        Calendar calendario = Calendar.getInstance();

        calendario.setTime(D_Fecha);

        minutoDia = calendario.get(Calendar.MINUTE);

        return minutoDia;
    }

    /**
     * OBTIENE UN STRING CON UNA FECHA CON EL FORMATO DIA/MES/ANIO
     *
     * @param D_Fecha LA FECHA A PARSEAR
     * @return UN STRING CON LA FECHA FORMATEADA
     */
    public static String obtenerFechaFormatoDDMMAAAA(Date D_Fecha) {
        String s_FechaFormatoDDMMAAAA = "";

        String dia = obtenerDia(D_Fecha);
        String mes = obtenerMes(D_Fecha);
        String anio = obtenerAnio(D_Fecha);

        if (mes.length() == 1) {
            mes = "0" + mes;
        }

        if (dia.length() == 1) {
            dia = "0" + dia;
        }

        s_FechaFormatoDDMMAAAA = dia + "/" + mes + "/" + anio;

        return s_FechaFormatoDDMMAAAA;
    }
    
    /**
     * OBTIENE UN STRING CON UNA FECHA CON EL FORMATO MES/DIA/ANIO
     *
     * @param D_Fecha LA FECHA A PARSEAR
     * @return UN STRING CON LA FECHA FORMATEADA
     */
    public static String obtenerFechaFormatoMMDDAAAA(Date D_Fecha) {
        String s_FechaFormatoDDMMAAAA = "";

        String dia = obtenerDia(D_Fecha);
        String mes = obtenerMes(D_Fecha);
        String anio = obtenerAnio(D_Fecha);

        if (mes.length() == 1) {
            mes = "0" + mes;
        }

        if (dia.length() == 1) {
            dia = "0" + dia;
        }

        s_FechaFormatoDDMMAAAA = mes + "/" + dia + "/" + anio;

        return s_FechaFormatoDDMMAAAA;
    }

    /**
     * OBTIENE EL DIA DE LA FECHA ESPECIFICADA
     *
     * @param D_Fecha LA FECHA OBJETIVO
     * @return EL DIA DE LA FECHA INDICADA
     */
    public static String obtenerDia(Date D_Fecha) {
        int dia;

        Calendar calendario = Calendar.getInstance();

        calendario.setTime(D_Fecha);

        dia = calendario.get(Calendar.DATE);

        return "" + dia;
    }

    /**
     * OBTIENE EL MES DE LA FECHA ESPECIFICADA
     *
     * @param D_Fecha LA FECHA OBJETIVO
     * @return EL MES DE LA FECHA INDICADA
     */
    public static String obtenerMes(Date D_Fecha) {
        int mes;

        Calendar calendario = Calendar.getInstance();

        calendario.setTime(D_Fecha);

        mes = calendario.get(Calendar.MONTH) + 1;

        return "" + mes;
    }

    /**
     * OBTIENE EL ANIO DE LA FECHA ESPECIFICADA
     *
     * @param D_Fecha LA FECHA OBJETIVO
     * @return EL ANIO DE LA FECHA INDICADA
     */
    public static String obtenerAnio(Date D_Fecha) {
        int anio;

        Calendar calendario = Calendar.getInstance();

        calendario.setTime(D_Fecha);

        anio = calendario.get(Calendar.YEAR);

        return "" + anio;
    }

    /**
     * OBTIENE EL NOMBRE DEL MES INDICADO
     *
     * @param i_NumeroMes EL NUMERO DE MES
     * @return EL NOMBRE DEL MES INDICADO
     */
    public static String obtenerNombreMes(int i_NumeroMes) {
        String nombreMes = "";

        switch (i_NumeroMes) {
            case 1:
                nombreMes = "ENERO";
                break;
            case 2:
                nombreMes = "FEBRERO";
                break;
            case 3:
                nombreMes = "MARZO";
                break;
            case 4:
                nombreMes = "ABRIL";
                break;
            case 5:
                nombreMes = "MAYO";
                break;
            case 6:
                nombreMes = "JUNIO";
                break;
            case 7:
                nombreMes = "JULIO";
                break;
            case 8:
                nombreMes = "AGOSTO";
                break;
            case 9:
                nombreMes = "SEPTIEMBRE";
                break;
            case 10:
                nombreMes = "OCTUBRE";
                break;
            case 11:
                nombreMes = "NOVIEMBRE";
                break;
            case 12:
                nombreMes = "DICIEMBRE";
                break;
            default:
                break;
        }

        return nombreMes;
    }

    /**
     * METODO QUE DEVUELVE UNA FECHA A PARTIR DE LOS DIAS QUE SE QUIERAN RESTAR O SUMAR A LA FECHA INDICADA EN FECHAINICIA
     *
     * @param D_FechaInicia
     * @param i_NumeroDiasPosterioresAnteriores
     * @return
     */
    public static Date obtenFechaObjetivo(Date D_FechaInicia, int i_NumeroDiasPosterioresAnteriores) {

        Date D_FechaFin = null;

        Calendar calendario = Calendar.getInstance();
        calendario.setTime(D_FechaInicia);

        calendario.add(Calendar.DATE, i_NumeroDiasPosterioresAnteriores);
        D_FechaFin = calendario.getTime();

        //System.out.println("La nueva fecha es : " +  D_FechaFin);

        return D_FechaFin;
    }

    /**
     * METODO QUE OBTIENE LA FECHA EN FORMATO AAAAMMDD A PARTIR DE UN STRING QUE CONTIENE LA FECHA EN FORMATO TIMESTAMP s_FormatoFecha = "yyyy-MM-dd hh:mm:ss"
     *
     * @param s_FechaObjetivo
     * @return LA FECHA CON FORMATO yyyyMMdd
     */
    public static String obtenerFechaFormatoAAAAMMDD(String s_FechaObjetivo) {
        String s_FormatoFecha = "yyyy-MM-dd hh:mm:ss";
        Date D_FechaObjetivo = crearFecha(s_FechaObjetivo, s_FormatoFecha);

        String s_Fecha = "";

        s_Fecha = obtenerFechaFormatoAAAAMMDD(D_FechaObjetivo);

        return s_Fecha;
    }

    /**
     * OBTIENE UN STRING CON UNA FECHA CON EL FORMATO ANIOMESDIA SIN SEPARADORES
     *
     * @param D_Fecha LA FECHA A PARSEAR
     * @return UN STRING CON LA FECHA FORMATEADA
     */
    public static String obtenerFechaFormatoAAAAMMDD(Date D_Fecha) {
        String s_FechaFormatoAAAAMMDD = "";

        String dia = obtenerDia(D_Fecha);
        String mes = obtenerMes(D_Fecha);
        String anio = obtenerAnio(D_Fecha);

        if (mes.length() == 1) {
            mes = "0" + mes;
        }

        if (dia.length() == 1) {
            dia = "0" + dia;
        }

        s_FechaFormatoAAAAMMDD = anio + mes + dia;

        return s_FechaFormatoAAAAMMDD;
    }

    /**
     * OBTIENE UN STRING CON UNA FECHA CON EL FORMATO ANIO-MES-DIA
     *
     * @param D_Fecha LA FECHA A PARSEAR
     * @return UN STRING CON LA FECHA FORMATEADA
     */
    public static String obtenerFechaFormatoAAAA_MM_DD(Date D_Fecha) {
        String s_FechaFormatoAAAA_MM_DD = "";

        String dia = obtenerDia(D_Fecha);
        String mes = obtenerMes(D_Fecha);
        String anio = obtenerAnio(D_Fecha);

        if (mes.length() == 1) {
            mes = "0" + mes;
        }

        if (dia.length() == 1) {
            dia = "0" + dia;
        }

        s_FechaFormatoAAAA_MM_DD = anio + "-" + mes + "-" + dia;

        return s_FechaFormatoAAAA_MM_DD;
    }

    /**
     *
     * @return LA FECHA ACTUAL EN UN DATE
     */
    public static Date obtenerFechaActual() {
        Calendar calendario = Calendar.getInstance();
        Date D_FechaActual = calendario.getTime();

        return D_FechaActual;
    }

    /**
     *
     * @return LA FECHA ACTUAL EN UN STRING CON FORMATO AAAA-MM-DD
     */
    public static String ObtenerFechaActualFormatoAAAA_MM_DD() {
        Date D_FechaActual = obtenerFechaActual();
        String s_FechaActual = ProcesaFechas.obtenerFechaFormatoAAAA_MM_DD(D_FechaActual);

        return s_FechaActual;
    }

    /**
     * METODO QUE VALIDA SI LOS DIAS INDICADOS FORMAN PARTE DEL MISMO MES O SI BIEN CORRESPONDEN A MESES DISTINTOS
     *
     * @param D_FechaActual
     * @param D_FechaAnterior
     * @return TRUE SI AMBAS FECHAS ESTAN EN EL MISMO MES Y FALSE EN OTRO CASO
     */
    public static boolean validarMesFechaActual(Date D_FechaActual, Date D_FechaAnterior) {

        boolean b_MismoMes = false;
        //System.out.println("Comparamos mes: " + D_FechaActual + "  ------ " + D_FechaAnterior );

        int i_MesActual = new Integer(obtenerMes(D_FechaActual)).intValue();

        int i_MesAnterior = new Integer(obtenerMes(D_FechaAnterior)).intValue();

        if (i_MesActual == i_MesAnterior) {
            b_MismoMes = true;
            //System.out.println("Mismo mes : " +  b_MismoMes);
        } else {
            //System.out.println("Mismo mes : " +  b_MismoMes);
        }

        return b_MismoMes;
    }

    /**
     *
     * @param D_FechaActual
     * @return
     */
    public static int numeroSemanaDelMes(Date D_FechaActual) {
        Calendar calendario = Calendar.getInstance();
        calendario.setTime(D_FechaActual);

        int numeroDeSemana = calendario.get(calendario.WEEK_OF_MONTH);

        //System.out.println("La fecha corresponde a la semana : " + numeroDeSemana);        

        return numeroDeSemana;
    }

    /**
     * OBTIENE EL NUMERO DE MES DE LA FECHA ESPECIFICADA
     *
     * @param D_Fecha LA FECHA OBJETIVO
     * @return EL NUMERO DE MES DE LA FECHA INDICADA
     */
    public static int obtenerNumeroMes(Date D_Fecha) {
        int mes;

        Calendar calendario = Calendar.getInstance();

        calendario.setTime(D_Fecha);

        mes = calendario.get(Calendar.MONTH) + 1;

        return mes;
    }

    public static int obtenerUltimoDiaDelMesActual(Date D_FechaActual) {
        int i_UltimoDiaMes = 0;
        Calendar calendario = Calendar.getInstance();
        calendario.setTime(D_FechaActual);

        i_UltimoDiaMes = calendario.getActualMaximum(calendario.DAY_OF_MONTH);

        return i_UltimoDiaMes;
    }

    /**
     * METODO QUE OBTIENE EL NUMERO DE DIAS DEL MES INDICADO EN LA FECHA
     *
     * @param D_Fecha LA FECHA QUE CONTIENE EL MES OBJETIVO Y EL AÑO DEL MISMO
     * @return UN ENTERO CON EL NUMERO DE DIAS DEL MES EN EL AÑO INDICADO
     */
    public static int obtenDiasEntreMesesInmediatos(Date D_Fecha) {
        int i_NumeroDiasEntreMesesInmediatos = 0;

        D_Fecha = obtenFechaInicioMes(D_Fecha);
        int i_mes = obtenerNumeroMes(D_Fecha);
        String s_NuevoDia = "01";
        int i_NuevoMes = i_mes + 1;
        int i_NuevoAnio = obtenerNumeroAnio(D_Fecha);
        if (i_NuevoMes > 12) {
            i_NuevoMes = 1;
            i_NuevoAnio = i_NuevoAnio + 1;
        }
        String s_NuevaFechaConMesInmediato = "" + i_NuevoAnio + "-" + i_NuevoMes + "-" + s_NuevoDia;
        Date D_FechaConMesInmediato = crearFecha(s_NuevaFechaConMesInmediato, "yyyy-MM-dd");
        System.out.println("De: " + D_Fecha + "    a: " + D_FechaConMesInmediato);
        i_NumeroDiasEntreMesesInmediatos = obtenDiasEntrePeriodo(D_Fecha, D_FechaConMesInmediato);

        return i_NumeroDiasEntreMesesInmediatos;
    }

    /**
     * OBTIENE LA FECHA CON EL SIGUIENTE FORMATO ANIO-MES-01
     *
     * @param D_Fecha
     * @return DATE CON EL FORMATO ANIO-MES-01
     */
    public static Date obtenFechaInicioMes(Date D_Fecha) {
        Date D_FechaInicioMes = null;
        String s_dia = "01";
        String s_mes = obtenerMes(D_Fecha);
        String s_anio = obtenerAnio(D_Fecha);
        String s_FechaConMesInicial = "" + s_anio + "-" + s_mes + "-" + s_dia;
        D_FechaInicioMes = crearFecha(s_FechaConMesInicial, "yyyy-MM-dd");
        return D_FechaInicioMes;
    }

    /**
     *
     * @param D_Fecha
     * @return
     */
    public static int obtenerNumeroAnio(Date D_Fecha) {
        String s_anio = obtenerAnio(D_Fecha);
        int i_Anio = 0;

        try {
            i_Anio = new Integer(s_anio).intValue();
        } catch (NumberFormatException nfe_Anio) {
            System.out.println("Ocurrio un error con la obtencion del anio..." + nfe_Anio.getMessage());
        }

        return i_Anio;
    }

    /**
     * OBTIENE EL DIA DE LA FECHA ESPECIFICADA
     *
     * @param D_Fecha LA FECHA OBJETIVO
     * @return EL DIA DE LA FECHA INDICADA
     */
    public static int obtenerNumeroDia(Date D_Fecha) {
        int dia;

        Calendar calendario = Calendar.getInstance();

        calendario.setTime(D_Fecha);

        dia = calendario.get(Calendar.DATE);

        return dia;
    }

    /**
     *
     * @param D_Fecha
     * @return
     */
    public static boolean isDomingo(Date D_Fecha) {
        boolean b_UltimoDia = false;
        int i_DiaActual = obtenerNumeroDia(D_Fecha);

        String s_Fecha = "" + D_Fecha;
        if (s_Fecha.startsWith("Sun ")) {
            b_UltimoDia = true;
        } else {
            b_UltimoDia = false;
        }
        //System.out.println("Dia de la semana Actual: " + i_DiaActual );
        //System.out.println(" Fecha " + D_Fecha);



        return b_UltimoDia;
    }

    /**
     * METODO QUE INDICA SI LA FECHA INDICADA CORRESPONDE AL ULTIMO DIA DEL MES
     *
     * @param D_Fecha
     * @return
     */
    public static boolean isUltimoDiaDelMes(Date D_Fecha) {
        boolean b_UltimoDiaDelMes = false;

        boolean b_ComienzaOtroMes = false;

        Date D_DiaSiguiente = obtenFechaObjetivo(D_Fecha, 1);
        b_ComienzaOtroMes = validarMesFechaActual(D_Fecha, D_DiaSiguiente);

        if (!b_ComienzaOtroMes) {
            b_UltimoDiaDelMes = true;
        }

        return b_UltimoDiaDelMes;
    }

    /**
     * CAMBIA EL FORMATO DE LA FECHA
     *
     * @param s_Fecha FECHA CON FORMATO DD/MM/AAAA
     * @return FECHA CON FORMATO AAAA-MM-DD
     */
    public static String cambiarFormatoFechaDDMMAAAtoAAAAMMDD(String s_Fecha) {
        String s_FechaNuevoFormato = "";
        String[] s_Temporal;
        String s_Delimitador = "/";
        s_Temporal = s_Fecha.split(s_Delimitador);


        if (s_Temporal.length == 3) {
            s_FechaNuevoFormato = s_Temporal[2] + "-" + s_Temporal[1] + "-" + s_Temporal[0];
        }

        return s_FechaNuevoFormato;
    }

    /**
     * OBTIENE LA FECHA QUE CORRESPONDE AL ULTIMO DIA DEL MES CONTENIDO EN LA FECHA INDICADA
     *
     * @param D_Fecha LA FECHA DEL MES QUE SE QUIERE OBTENER EL ULTIMO DIA
     * @return LA FECHA DEL ULTIMO DIA DEL MES
     */
    public static Date obtenFechaFinDeMes(Date D_Fecha) {
        Date D_FechaFinMes = D_Fecha;

        if (isUltimoDiaDelMes(D_Fecha)) {
        } else {
            D_Fecha = obtenFechaObjetivo(D_Fecha, 1);
            D_FechaFinMes = obtenFechaFinDeMes(D_Fecha);
        }

        return D_FechaFinMes;
    }

    /**
     * DEVUELVE EL NUMERO DE MES SEGUN ELNOMBRE DEL MISMO
     *
     * @param s_NombreMes
     * @return EL NUMERO DEL MES INDICADO
     */
    public static int obtenerMesAPartirDelNombre(String s_NombreMes) {
        int i_NumeroMes = 0;

        s_NombreMes = s_NombreMes.toUpperCase();

        if (s_NombreMes.compareTo("ENERO") == 0) {
            i_NumeroMes = 1;
        } else {
            if (s_NombreMes.compareTo("FEBRERO") == 0) {
                i_NumeroMes = 2;
            } else {
                if (s_NombreMes.compareTo("MARZO") == 0) {
                    i_NumeroMes = 3;
                } else {
                    if (s_NombreMes.compareTo("ABRIL") == 0) {
                        i_NumeroMes = 4;
                    } else {
                        if (s_NombreMes.compareTo("MAYO") == 0) {
                            i_NumeroMes = 5;
                        } else {
                            if (s_NombreMes.compareTo("JUNIO") == 0) {
                                i_NumeroMes = 6;
                            } else {
                                if (s_NombreMes.compareTo("JULIO") == 0) {
                                    i_NumeroMes = 7;
                                } else {
                                    if (s_NombreMes.compareTo("AGOSTO") == 0) {
                                        i_NumeroMes = 8;
                                    } else {
                                        if (s_NombreMes.compareTo("SEPTIEMBRE") == 0) {
                                            i_NumeroMes = 9;
                                        } else {
                                            if (s_NombreMes.compareTo("OCTUBRE") == 0) {
                                                i_NumeroMes = 10;
                                            } else {
                                                if (s_NombreMes.compareTo("NOVIEMBRE") == 0) {
                                                    i_NumeroMes = 11;
                                                } else {
                                                    if (s_NombreMes.compareTo("DICIEMBRE") == 0) {
                                                        i_NumeroMes = 12;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        return i_NumeroMes;
    }

    /**
     * DEVUELVE EL NUMERO DE MES A DOS DIGITOS, SEGUN ELNOMBRE DEL MISMO
     *
     * @param s_NombreMes
     * @return EL NUMERO DEL MES INDICADO
     */
    public static String obtenerDosDigitosMesAPartirDelNombre(String s_NombreMes) {
        int i_NumeroMes = 0;
        String s_DosDigitosMes = "";

        s_NombreMes = s_NombreMes.toUpperCase();

        if (s_NombreMes.compareTo("ENERO") == 0) {
            i_NumeroMes = 1;
        } else {
            if (s_NombreMes.compareTo("FEBRERO") == 0) {
                i_NumeroMes = 2;
            } else {
                if (s_NombreMes.compareTo("MARZO") == 0) {
                    i_NumeroMes = 3;
                } else {
                    if (s_NombreMes.compareTo("ABRIL") == 0) {
                        i_NumeroMes = 4;
                    } else {
                        if (s_NombreMes.compareTo("MAYO") == 0) {
                            i_NumeroMes = 5;
                        } else {
                            if (s_NombreMes.compareTo("JUNIO") == 0) {
                                i_NumeroMes = 6;
                            } else {
                                if (s_NombreMes.compareTo("JULIO") == 0) {
                                    i_NumeroMes = 7;
                                } else {
                                    if (s_NombreMes.compareTo("AGOSTO") == 0) {
                                        i_NumeroMes = 8;
                                    } else {
                                        if (s_NombreMes.compareTo("SEPTIEMBRE") == 0) {
                                            i_NumeroMes = 9;
                                        } else {
                                            if (s_NombreMes.compareTo("OCTUBRE") == 0) {
                                                i_NumeroMes = 10;
                                            } else {
                                                if (s_NombreMes.compareTo("NOVIEMBRE") == 0) {
                                                    i_NumeroMes = 11;
                                                } else {
                                                    if (s_NombreMes.compareTo("DICIEMBRE") == 0) {
                                                        i_NumeroMes = 12;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (i_NumeroMes > 9) {
            s_DosDigitosMes = "" + i_NumeroMes;
        } else {
            s_DosDigitosMes = "0" + i_NumeroMes;
        }

        return s_DosDigitosMes;
    }

    /**
     *
     *
     * @param s_Fecha
     * @return
     */
    public static String cambiarFormatoFechaToDDgMMgAAAA(String s_Fecha) {
        String s_FechaNuevoFormato = "";
        String[] s_Temporal;
        String s_Delimitador = "-";
        s_Temporal = s_Fecha.split(s_Delimitador);


        if (s_Temporal.length == 3) {
            s_FechaNuevoFormato = s_Temporal[2] + "/" + s_Temporal[1] + "/" + s_Temporal[0];
        }

        return s_FechaNuevoFormato;
    }

    public static String formatoFecha(String fecha, String formatoSalida) {
        // El formato de entrada debera ser como los timestamp de interbase (AAAA-MM-DD HH:MM:SS.DDDD)
        // podria modificarse el metodo de manera que se le indicara el formato
        // de entrada tambien, pero eso sera para un modificacion futura, por el momento tomara solo dos
        // formatos timestamp con hora y sin hora

        String[] meses = {"", "ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO", "JULIO", "AGOSTO", "SEPTIEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"};

        String salida = formatoSalida;
        StringTokenizer stFecha = new StringTokenizer(fecha, " "); //Elimina la hora si existe
        stFecha = new StringTokenizer(stFecha.nextToken(), "-");

        String anio = stFecha.nextToken();
        String mes = stFecha.nextToken();
        String dia = stFecha.nextToken();
        // se utiliza remplaza cadena para darle el formato deseado
        //remplazaCadena(String cadenaCompleta, String subCadena, String cadenaRemplazo)
        salida = remplazaCadena(salida, "mms", meses[Integer.parseInt(mes)]);
        salida = remplazaCadena(salida, "MMS", meses[Integer.parseInt(mes)]);
        salida = remplazaCadena(salida, "AAAA", anio);
        salida = remplazaCadena(salida, "AA", anio.substring(2, 4));
        salida = remplazaCadena(salida, "MM", mes);
        salida = remplazaCadena(salida, "DD", dia);
        salida = remplazaCadena(salida, "aaaa", anio);
        salida = remplazaCadena(salida, "aa", anio.substring(2, 4));
        salida = remplazaCadena(salida, "mm", mes);
        salida = remplazaCadena(salida, "dd", dia);

        return salida;
    }

    public static String remplazaCadena(String cadenaCompleta, String subCadena, String cadenaRemplazo) {
        String cadenaSalida = "";
        String cadenaAux = cadenaCompleta;

        int indiceCadena = -1;
        while ((indiceCadena = cadenaAux.indexOf(subCadena)) >= 0) {
            cadenaSalida = cadenaSalida + cadenaAux.substring(0, indiceCadena) + cadenaRemplazo;
            cadenaAux = cadenaAux.substring(indiceCadena + subCadena.length(), cadenaAux.length());

        }
        cadenaSalida = cadenaSalida + cadenaAux;
        return cadenaSalida;
    }

    public static String formatoMonedaMX(double numero, boolean signo) {
        //java.text.NumberFormat nf = java.text.NumberFormat.getInstance();
        java.text.NumberFormat nf = java.text.NumberFormat.getNumberInstance();
        nf.setMaximumFractionDigits(2);
        nf.setMinimumFractionDigits(2);

        String numeroFormato = nf.format(numero);

        if (signo) {
            numeroFormato = "$ " + numeroFormato;
        }

        return numeroFormato;

    }

    public String convierteFechaMMDDAAAA(String fecha) {
        String dia = "";
        String mes = "";
        String anio = "";
        try {
            java.util.StringTokenizer parametrosFecha = new StringTokenizer(fecha, "-");
            anio = Integer.parseInt(parametrosFecha.nextToken()) + "";
            mes = Integer.parseInt(parametrosFecha.nextToken()) + "";
            dia = Integer.parseInt(parametrosFecha.nextToken()) + "";
        } catch (Exception e) {
            System.err.println("error " + e.getMessage() + " desde " + this.getClass().getName());
        }
        return mes + "/" + dia + "/" + anio;
    }
    
    public static int comparaAnioBisiesto(int year){
    	int dias = 365;
    	
    	if (((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)){
    		dias = 366;
    	}
    	
    	return dias;
    }
}

