package clases;

import java.util.Locale;

public class Util {

    public static String remplazaCadena(String cadenaCompleta, String subCadena, String cadenaRemplazo) {
        String cadenaSalida = "";
        String cadenaAux = cadenaCompleta;

        int indiceCadena = -1;
        while ((indiceCadena = cadenaAux.indexOf(subCadena)) >= 0) {
            cadenaSalida = cadenaSalida + cadenaAux.substring(0, indiceCadena) + cadenaRemplazo;
            cadenaAux = cadenaAux.substring(indiceCadena + subCadena.length(), cadenaAux.length());

        }
        cadenaSalida = cadenaSalida + cadenaAux;
        return cadenaSalida;
    }

    public static String formatoMoneda(double numero, boolean signo) {
//java.text.NumberFormat nf = java.text.NumberFormat.getInstance();
        java.text.NumberFormat nf = java.text.NumberFormat.getNumberInstance(new Locale("en", "US"));
        nf.setMaximumFractionDigits(2);
        nf.setMinimumFractionDigits(2);

        String numeroFormato = nf.format(numero);

        if (signo) {
            numeroFormato = "$ " + numeroFormato;
        }

        return numeroFormato;

    }

    public static String formatoMonedaMX(double numero, boolean signo) {
//java.text.NumberFormat nf = java.text.NumberFormat.getInstance();
        java.text.NumberFormat nf = java.text.NumberFormat.getNumberInstance();
        nf.setMaximumFractionDigits(2);
        nf.setMinimumFractionDigits(2);

        String numeroFormato = nf.format(numero);

        if (signo) {
            numeroFormato = "$ " + numeroFormato;
        }

        return numeroFormato;

    }

    public static String formatoMonedaMXHTML(double numero, boolean signo) {
//java.text.NumberFormat nf = java.text.NumberFormat.getInstance();
        java.text.NumberFormat nf = java.text.NumberFormat.getNumberInstance();
        nf.setMaximumFractionDigits(2);
        nf.setMinimumFractionDigits(2);

        String numeroFormato = nf.format(numero);

        if (signo) {
            numeroFormato = "$&nbsp;" + numeroFormato;
        }

        return numeroFormato;

    }

    public static String GetNumberFormat(float numero) {
        return formatoMoneda(numero, false);
    }

    public static String formatoMoneda(float numeroF, boolean signo) {
        String numeroFormato = "";
        String numero = "" + numeroF;
        if (numero == null) {
            numero = "";
        }
        if (!numero.trim().equals("")) {
            //java.text.NumberFormat nf = java.text.NumberFormat.getInstance();
            java.text.NumberFormat nf = java.text.NumberFormat.getNumberInstance(new Locale("en", "US"));
            nf.setMaximumFractionDigits(2);
            nf.setMinimumFractionDigits(2);
            //numeroFormato="Entro al if";
            try {
                numeroFormato = nf.format(Double.parseDouble(numero.trim()));

                if (signo) {
                    numeroFormato = "$ " + numeroFormato;
                }
            } catch (NumberFormatException e) {
                numeroFormato = "";//"Se causo la excepcion numerica";
            }
        }

        return numeroFormato;

    }

    public static String formatoMoneda(String numero, boolean signo) {
        String numeroFormato = "";
        if (numero == null) {
            numero = "";
        }
        if (!numero.trim().equals("")) {
            //java.text.NumberFormat nf = java.text.NumberFormat.getInstance();
            java.text.NumberFormat nf = java.text.NumberFormat.getNumberInstance(new Locale("en", "US"));
            nf.setMaximumFractionDigits(2);
            nf.setMinimumFractionDigits(2);
            //numeroFormato="Entro al if";
            try {
                numeroFormato = nf.format(Double.parseDouble(numero.trim()));

                if (signo) {
                    numeroFormato = "$ " + numeroFormato;
                }
            } catch (NumberFormatException e) {
                numeroFormato = "";//"Se causo la excepcion numerica";
            }
        }

        return numeroFormato;

    }

    public double Redondear(double numero) {
        System.out.println("Antes redondear" + numero);
        return Math.rint(numero * 100) / 100;

    }

    public static String formatoMonedaMX(String numero, boolean signo) {
        String numeroFormato = "";
        if (numero == null) {
            numero = "";
        }
        if (!numero.trim().equals("")) {
            java.text.NumberFormat nf = java.text.NumberFormat.getInstance(Locale.GERMAN);
            java.text.DecimalFormat form = (java.text.DecimalFormat) nf;
            form.applyPattern("#######");

//    java.text.NumberFormat nf = java.text.NumberFormat.getNumberInstance();
//    nf.setMaximumFractionDigits(2);
//    nf.setMinimumFractionDigits(2);
            try {
//      numeroFormato = nf.format(Double.parseDouble(numero.trim()));
                numeroFormato = form.format(Double.parseDouble(numero.trim()));

                if (signo) {
                    numeroFormato = "$&nbsp; " + numeroFormato;
                }
            } catch (NumberFormatException e) {
                numeroFormato = "";//"Se causo la excepcion numerica";
            }
        }

        return numeroFormato;

    }

    public int cadenaVaciaCeroNull(String varstr) {
        int salida = 0;
        //System.out.println(" entrada " + varstr);
        if (varstr != null) {
            salida = Integer.parseInt(varstr.trim());
        }
        //System.out.println(" salida" + salida);
        return salida;
    }

    public String nuloCadenaVacia(String varstr) {
        String Salida = "";
        if (varstr != null) {
            Salida = varstr.trim();
        }
        return Salida;
    }

    public static String nuloCadenaVacia(String varstr, boolean trim) {
        String Salida = "";
        if (varstr != null) {
            Salida = varstr;
            if (trim) {
                Salida = varstr.trim();
            }
        }
        return Salida;
    }

    public String formatoSinComa(String cantidad) {
        String str = cantidad;
        if (cantidad == null || cantidad == "") {
            str = "0";
        }
        for (int i = 0; i < cantidad.length(); i++) {
            if (cantidad.charAt(i) == ',') {
                str = "";
                str = cantidad.substring(0, i);
                str += cantidad.substring(i + 1, cantidad.length());
                i = cantidad.length();
            }
        }
        return str;
    }

    public static String rellenaCaracteres(String cadenaOriginal, int numCaracteres, boolean derecha, String caracter) {
        String cadena = "";
        String cadenaAuxiliar = "";
        for (int i = 1; i < numCaracteres; i++) {
            cadenaAuxiliar += caracter;
        }
        if (derecha) {
            cadena = cadenaOriginal + cadenaAuxiliar;
        } else {
            cadena = cadenaAuxiliar + cadenaOriginal;
        }
        return cadena;
    }
}
