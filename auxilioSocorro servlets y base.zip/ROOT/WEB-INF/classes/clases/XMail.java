package clases;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.MessagingException;
import javax.mail.Multipart;

/**
 *
 * @author pedraza
 */
public class XMail {
    /* PARA GUARDAR LA CONFIGURACION DEL SERVIDOR SMTP */

    Properties props = new Properties();

    /* Parametros de configuracion del servidor de correo */
    protected String SMTPServer = "smtp.gmail.com";     // Dirección del servidor de correo
    protected boolean TLS = true;                               // Si utiliza seguridad
    protected int Port = 465;                                   // Puerto
    protected String User = "octodevs@gmail.com";            // Usuario que envia el correo ej. usuario@correo.com
    protected String Password = "fernandonosabe";  
    
      private Session session;
    private MimeMessage message;
    private Multipart multipart;                     // Password de la cuenta

    public XMail() {
        props.setProperty("mail.smtp.host", this.SMTPServer);
        props.setProperty("mail.smtp.starttls.enable", "" + this.TLS);
        props.setProperty("mail.smtp.port", "" + this.Port);
        props.setProperty("mail.smtp.user", this.User);
        props.setProperty("mail.smtp.auth", "true");

    }

    public XMail(String server, boolean tls, int port, String user, String password) {
        this.SMTPServer = server;
        this.TLS = tls;
        this.Port = port;
        this.User = user;
        this.Password = password;
        props.setProperty("mail.smtp.host", this.SMTPServer);
        props.setProperty("mail.smtp.starttls.enable", "" + this.TLS);
        props.setProperty("mail.smtp.port", "" + this.Port);
        props.setProperty("mail.smtp.user", this.User);
    }

    public void sendMessage(String from, String to, String cc, String cco, String subject, String text) throws AddressException, MessagingException {
        Session session = Session.getDefaultInstance(props);
        MimeMessage message = new MimeMessage(session);
//	    message.setFrom(new InternetAddress(this.User));
        // ------------------------------------------------
        if (!from.equals("")) {
            message.setFrom(new InternetAddress(from));
        } else {
            message.setFrom(new InternetAddress(this.User));
        }
        // ------------------------------------------------
        if (!to.equals("")) {
            String arrTo[] = to.split(";");
            for (String strTo : arrTo) {
                message.addRecipient(Message.RecipientType.TO,
                        new InternetAddress(strTo));
            }
        }
        // ------------------------------------------------
        if (!cc.equals("")) {
            String arrCC[] = cc.split(";");
            for (String strCC : arrCC) {
                message.addRecipient(Message.RecipientType.CC,
                        new InternetAddress(strCC));
            }
        }
        // ------------------------------------------------
        if (!cco.equals("")) {
            String arrCCO[] = cco.split(";");
            for (String strCCO : arrCCO) {
                message.addRecipient(Message.RecipientType.BCC,
                        new InternetAddress(strCCO));
            }
        }
        // ------------------------------------------------
        message.setSubject(subject);
        message.setDataHandler(new DataHandler(new ByteArrayDataSource(text, "text/html")));
        // --------------- ENVIAR EL CORREO ---------------
        Transport t = session.getTransport("smtp");

        if (User.equals("") && Password.equals("")) {
            t.connect();
        } else {
            t.connect(this.User, this.Password);
        }

        t.sendMessage(message, message.getAllRecipients());
        t.close();
    }

 public void addAttachment(byte[] attachmentIN, String fileName) throws MessagingException{
	    MimeBodyPart attachmentBodyPart = new MimeBodyPart();
            String nombreArhivo="poliza"+fileName+".pdf";
            final byte[] attachment=attachmentIN;
            attachmentBodyPart.setDataHandler(
           new DataHandler(
                   new DataSource() {
            public String getContentType() {
                return "application/pdf";
            }
            public InputStream getInputStream() throws IOException {
                return new ByteArrayInputStream(attachment);
            }
            public String getName() {
                return "poliza.pdf";
            }
            public OutputStream getOutputStream() throws IOException {
                return null;
            }}));
         attachmentBodyPart.setFileName(nombreArhivo);
        multipart.addBodyPart(attachmentBodyPart);

        //message.setContent(multipart);
    }
    /* Metodos */
    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public String getUser() {
        return User;
    }

    public void setUser(String User) {
        this.User = User;
        props.setProperty("mail.smtp.user", this.User);
    }

    public int getPort() {
        return Port;
    }

    public void setPort(int Port) {
        this.Port = Port;
        props.setProperty("mail.smtp.port", "" + this.Port);
    }

    public boolean isTLS() {
        return TLS;
    }

    public void setTLS(boolean TLS) {
        this.TLS = TLS;
        props.setProperty("mail.smtp.starttls.enable", "" + this.TLS);
    }

    public String getSMTPServer() {
        return SMTPServer;
    }

    public void setSMTPServer(String SMTPServer) {
        this.SMTPServer = SMTPServer;
        props.setProperty("mail.smtp.host", this.SMTPServer);
    }
}

class ByteArrayDataSource implements DataSource {

    private byte[] data; // data
    private String type; // content-type

    /* Create a DataSource from an input stream */
    public ByteArrayDataSource(InputStream is, String type) {
        this.type = type;
        try {
            ByteArrayOutputStream os = new ByteArrayOutputStream();
            int ch;

            while ((ch = is.read()) != -1) {
                os.write(ch);
            }
            data = os.toByteArray();

        } catch (IOException ioex) {
        }
    }

    /* Create a DataSource from a byte array */
    public ByteArrayDataSource(byte[] data, String type) {
        this.data = data;
        this.type = type;
    }

    /* Create a DataSource from a String */
    public ByteArrayDataSource(String data, String type) {
        try {
            // Assumption that the string contains only ASCII
            // characters! Otherwise just pass a charset into this
            // constructor and use it in getBytes()
            this.data = data.getBytes("iso-8859-1");
        } catch (UnsupportedEncodingException uex) {
        }
        this.type = type;
    }

    public InputStream getInputStream() throws IOException {
        if (data == null) {
            throw new IOException("no data");
        }
        return new ByteArrayInputStream(data);
    }

    public OutputStream getOutputStream() throws IOException {
        throw new IOException("cannot do this");
    }

    public String getContentType() {
        return type;
    }

    public String getName() {
        return "dummy";
    }
}
