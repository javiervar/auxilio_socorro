/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import beans.Catalogo;
import beans.Lugar;
import beans.UsuarioContacto;
import beansDAO.ColoniaDAO;
import beansDAO.EstadoDAO;
import beansDAO.LugarDAO;
import beansDAO.MunicipioDAO;
import beansDAO.UsuarioContactoDAO;
import beansTMP.MuestraEdoMunCol;
import javax.servlet.http.HttpServlet;
import beansTMP.Respuesta;
import clases.Util;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import com.google.gson.Gson;
import java.util.List;

/**
 *
 * @author octodevs
 */
public class Consultas extends HttpServlet {

    String json = "";
    Respuesta respuesta = null;
    Util util = null;

    public Consultas() {
        super();
    }

    protected void processsRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        util = new Util();

        int proceso = util.cadenaVaciaCeroNull((String) request.getParameter("operacion"));
        String callback = util.nuloCadenaVacia((String) request.getParameter("callback"));
        String semilla = util.nuloCadenaVacia((String) request.getParameter("api"));
        System.out.println("El proceso " + proceso + " desde " + this.getClass().getName());
        respuesta = null;
        json = "";
        if (semilla.equals("0ct0d3v5")) {
            procesos(proceso, request, response);
        } else {
            this.respuesta = new Respuesta(0, "Credenciales erroneas");
        }

        json = new Gson().toJson(respuesta);
        if (callback.equals("")) {
            response.setContentType("application/javascript");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write(json);
        } else {
            response.setContentType("application/javascript");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write(callback + "(" + json + ")");
        }
    }

    private void procesos(int proceso, HttpServletRequest request, HttpServletResponse response) {
        switch (proceso) {
            case 1:
                List<Catalogo> unCatalogo = null;
                int tipoCatalogo = util.cadenaVaciaCeroNull((String) request.getParameter("tipoCatalogo"));
                switch (tipoCatalogo) {
                    case 1: //ConsultaEstado
                        EstadoDAO consultaEstado = new EstadoDAO();
                        unCatalogo = consultaEstado.consultaLista();
                        this.respuesta = new Respuesta(proceso, "", unCatalogo);
                        break;
                    case 2: //ConsultaMunicipio
                        MunicipioDAO consultaMunicipio = new MunicipioDAO();
                        int estadoId = util.cadenaVaciaCeroNull((String) request.getParameter("estadoId"));
                        unCatalogo = consultaMunicipio.consultaLista(estadoId);
                        this.respuesta = new Respuesta(proceso, "", unCatalogo);
                        break;
                    case 3: //ConsultaColonia
                        //unCatalogo = ;
                        this.respuesta = new Respuesta(proceso, "", unCatalogo);
                        break;
                    case 4: //ConsultaTipoLugar
                        //unCatalogo = ;
                        this.respuesta = new Respuesta(proceso, "", unCatalogo);
                        break;
                    case 5: //ConsultaTipoContacto
                        //unCatalogo = ;
                        this.respuesta = new Respuesta(proceso, "", unCatalogo);
                        break;
                }
                break;
            case 2: // Consulta Lugar
                int tipoLugar = util.cadenaVaciaCeroNull((String) request.getParameter("tipoLugar"));
                LugarDAO consulta = new LugarDAO();
                List<Lugar> losLugares = null;
                losLugares = consulta.consulta(tipoLugar);
                this.respuesta = new Respuesta();
                respuesta.setError(2);
                respuesta.setListaLugares(losLugares);
                respuesta.setMensaje("");
                break;
            case 3: // Inserta Contacto
                UsuarioContacto unContacto = new UsuarioContacto();
                unContacto.setTelefono(util.nuloCadenaVacia((String) request.getParameter("telefono")));
                unContacto.setTipoContacto(util.cadenaVaciaCeroNull((String) request.getParameter("tipoContacto")));
                unContacto.setUsuarioId(util.cadenaVaciaCeroNull((String) request.getParameter("idUsuario")));
                UsuarioContactoDAO inserta = new UsuarioContactoDAO();
                inserta.inserta(unContacto);
                this.respuesta = new Respuesta(3, "Registro Exitoso");
                break;
            case 4: // Consulta Lista Contactos Emergencia
                List<UsuarioContacto> listaContactos = null;
                UsuarioContactoDAO consulta4 = new UsuarioContactoDAO();
                int usuarioId = util.cadenaVaciaCeroNull((String) request.getParameter("usuarioId"));
                listaContactos = consulta4.consultaContactosPorTipo(usuarioId);
                this.respuesta = new Respuesta();
                respuesta.setError(4);
                respuesta.setMensaje("");
                respuesta.setListaContactos(listaContactos);
                break;
            case 5: //Consulta Lugar
                String cp = util.nuloCadenaVacia((String) request.getParameter("cp"));
                int tamanioCP = cp.length();
                String otroCP = "";
                if (tamanioCP < 5) {
                    otroCP = "0" + cp;
                } else {
                    otroCP = cp;
                }
                MuestraEdoMunCol unLugar = null;
                ColoniaDAO consultaLugar = new ColoniaDAO();
                unLugar = consultaLugar.obtenLugar(cp);
                if (unLugar != null) {
                    this.respuesta = new Respuesta(5, "", unLugar);
                } else {
                    this.respuesta = new Respuesta(0, "Ocurrio un error al recuperar el lugar");
                }
                break;
            case 6:
                LugarDAO consulta6 = new LugarDAO();
                List<Lugar> losLugares6 = null;
                losLugares6 = consulta6.consulta();
                this.respuesta = new Respuesta();
                respuesta.setError(6);
                respuesta.setListaLugares(losLugares6);
                respuesta.setMensaje("");
                break;
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processsRequest(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processsRequest(request, response);
    }

}
